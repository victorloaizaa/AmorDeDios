# Funeraria Amor de Dios - Frontend

Sitio web y tienda de planes funerarios de la Funeraria Amor de Dios, hecho en React para DSY1104 Desarrollo Fullstack II.

**Integrantes:** Victor Loaiza, Benjamin Sotelo y Sergio Santamaria

## Tecnologías

- React 19 + React Router (navegación sin recargar la página)
- Vite (servidor de desarrollo y build)
- Bootstrap 5.3 (grilla responsive y componentes)
- Jasmine + Karma (pruebas unitarias) y karma-coverage (cobertura)

## Cómo correrlo

```bash
npm install
npm run dev
```

Después abrir la dirección que muestra la terminal (normalmente http://localhost:5173).

## Pruebas

```bash
npm test                 # corre las pruebas en Chrome
npm run test:cobertura   # corre las pruebas y genera el reporte en /coverage
```

El reporte de cobertura se abre en `coverage/html/index.html`.

## Estructura

```
src/
  components/   componentes reutilizables (Navbar, Footer, ProductoCard, FiltroCategorias, ItemCarrito, ServicioCard)
  pages/        una página por ruta (Home, Tienda, Carrito, Contacto, Login, Prearreglos, servicios...)
  data/         catálogo de productos
  utils/        lógica del carrito y validaciones del formulario
```

Las pruebas están al lado de cada archivo con el nombre `*.test.js`.
