import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

import Home from './pages/Home';
import Nosotros from './pages/Nosotros';
import Servicios from './pages/Servicios';
import Tienda from './pages/Tienda';
import Contacto from './pages/Contacto';
import Login from './pages/Login';
import Carrito from './pages/Carrito';

// Páginas de Subservicios
import VelatorioCapilla from './pages/VelatorioCapilla';
import Cremacion from './pages/Cremacion';
import Sucursales from './pages/Sucursales';
import Traslados from './pages/Traslados';
import TramitesDocumentacion from './pages/TramitesDocumentacion';
import Floristeria from './pages/Floristeria';
import Prearreglos from './pages/Prearreglos';
import AcompanamientoEspiritual from './pages/AcompanamientoEspiritual';
import ContencionEmocional from './pages/ContencionEmocional';
import ConveniosSeguros from './pages/ConveniosSeguros';

export default function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/nosotros" element={<Nosotros />} />
        <Route path="/servicios" element={<Servicios />} />
        
        <Route path="/velatorio-capilla" element={<VelatorioCapilla />} />
        <Route path="/cremacion" element={<Cremacion />} />
        <Route path="/traslados" element={<Traslados />} />
        <Route path="/tramites-documentacion" element={<TramitesDocumentacion />} />
        <Route path="/floristeria" element={<Floristeria />} />
        <Route path="/prearreglos" element={<Prearreglos />} />
        <Route path="/acompanamiento-espiritual" element={<AcompanamientoEspiritual />} />
        <Route path="/contencion-emocional" element={<ContencionEmocional />} />
        <Route path="/convenios-seguros" element={<ConveniosSeguros />} />
        <Route path="/sucursales" element={<Sucursales />} />

        <Route path="/tienda" element={<Tienda />} />
        <Route path="/contacto" element={<Contacto />} />
        <Route path="/login" element={<Login />} />
        <Route path="/carrito" element={<Carrito />} />
      </Routes>
      <Footer />
    </Router>
  );
}