// Reglas de validación del formulario de contacto.
// Cada función devuelve el mensaje de error, o '' si el valor está bien.

export const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export const regexTelefono = /^(\+?56)?\s?9\s?\d{4}\s?\d{4}$/; // celular chileno

export function validarNombre(valor) {
  if (valor.trim().length < 3) {
    return 'Ingresa tu nombre completo (mínimo 3 caracteres).';
  }
  return '';
}

export function validarCorreo(valor) {
  if (!regexCorreo.test(valor.trim())) {
    return 'Ingresa un correo válido, por ejemplo nombre@correo.cl';
  }
  return '';
}

export function validarTelefono(valor) {
  if (!regexTelefono.test(valor.trim())) {
    return 'Ingresa un teléfono chileno válido, ej: +56 9 1234 5678';
  }
  return '';
}

export function validarPlan(valor) {
  if (valor === '') {
    return 'Selecciona el plan que más te interesa.';
  }
  return '';
}
