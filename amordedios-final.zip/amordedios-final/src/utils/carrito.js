// Funciones del carrito. Las dejamos aparte para usarlas en Tienda, Carrito y Navbar
// y para poder probarlas sin tener que renderizar los componentes.

export const CLAVE_CARRITO = 'carrito_amor_de_dios';

export function leerCarrito() {
  try {
    const datos = localStorage.getItem(CLAVE_CARRITO);
    return datos ? JSON.parse(datos) : [];
  } catch {
    // si lo guardado está corrupto partimos con el carrito vacío
    return [];
  }
}

export function guardarCarrito(items) {
  localStorage.setItem(CLAVE_CARRITO, JSON.stringify(items));
  // avisamos para que el Navbar actualice el contador
  window.dispatchEvent(new Event('carrito-actualizado'));
}

// Devuelve un carrito nuevo con el producto agregado (si ya estaba, suma 1)
export function agregarProducto(items, producto) {
  const existe = items.find((item) => item.id === producto.id);

  if (existe) {
    return items.map((item) =>
      item.id === producto.id ? { ...item, cantidad: item.cantidad + 1 } : item
    );
  }

  return [
    ...items,
    {
      id: producto.id,
      nombre: producto.nombre,
      categoria: (producto.categoria || 'planes').toUpperCase(),
      precio: producto.precio,
      cantidad: 1,
      imagen: producto.imagen,
    },
  ];
}

// delta es +1 o -1. Si la cantidad llega a 0 se saca el producto
export function cambiarCantidad(items, id, delta) {
  return items
    .map((item) => (item.id === id ? { ...item, cantidad: item.cantidad + delta } : item))
    .filter((item) => item.cantidad > 0);
}

export function eliminarProducto(items, id) {
  return items.filter((item) => item.id !== id);
}

export function calcularTotal(items) {
  return items.reduce((total, item) => total + item.precio * item.cantidad, 0);
}

export function contarUnidades(items) {
  return items.reduce((total, item) => total + (item.cantidad || 1), 0);
}

export function formatearPrecio(precio) {
  return new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    minimumFractionDigits: 0,
  }).format(precio);
}
