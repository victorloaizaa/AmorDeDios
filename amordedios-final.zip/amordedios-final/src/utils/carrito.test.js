import {
  CLAVE_CARRITO,
  leerCarrito,
  guardarCarrito,
  agregarProducto,
  cambiarCantidad,
  eliminarProducto,
  calcularTotal,
  contarUnidades,
  formatearPrecio,
} from './carrito';

// productos de prueba (no usamos el catálogo real para que no cambien los resultados)
const corona = { id: 'corona', nombre: 'Corona', categoria: 'flores', precio: 75000, imagen: '/img/corona.jpg' };
const urna = { id: 'urna', nombre: 'Urna', categoria: 'urnas', precio: 380000, imagen: '/img/urna.jpg' };

describe('utils/carrito - lógica del carrito', () => {
  describe('agregarProducto', () => {
    it('agrega un producto nuevo con cantidad 1 y la categoría en mayúsculas', () => {
      const resultado = agregarProducto([], corona);

      expect(resultado.length).toBe(1);
      expect(resultado[0].cantidad).toBe(1);
      expect(resultado[0].categoria).toBe('FLORES');
    });

    it('si el producto ya estaba suma una unidad en vez de duplicarlo', () => {
      const carrito = agregarProducto([], corona);
      const resultado = agregarProducto(carrito, corona);

      expect(resultado.length).toBe(1);
      expect(resultado[0].cantidad).toBe(2);
    });

    it('no modifica el arreglo original', () => {
      const carrito = [];
      agregarProducto(carrito, corona);
      expect(carrito.length).toBe(0);
    });
  });

  describe('cambiarCantidad y eliminarProducto', () => {
    it('suma y resta unidades', () => {
      const carrito = [{ ...corona, cantidad: 2 }];

      expect(cambiarCantidad(carrito, 'corona', 1)[0].cantidad).toBe(3);
      expect(cambiarCantidad(carrito, 'corona', -1)[0].cantidad).toBe(1);
    });

    it('saca el producto cuando la cantidad llega a 0', () => {
      const carrito = [{ ...corona, cantidad: 1 }, { ...urna, cantidad: 1 }];
      const resultado = cambiarCantidad(carrito, 'corona', -1);

      expect(resultado.length).toBe(1);
      expect(resultado[0].id).toBe('urna');
    });

    it('eliminarProducto quita solo el producto indicado', () => {
      const carrito = [{ ...corona, cantidad: 3 }, { ...urna, cantidad: 1 }];
      const resultado = eliminarProducto(carrito, 'urna');

      expect(resultado.map((i) => i.id)).toEqual(['corona']);
    });
  });

  describe('totales', () => {
    it('calcularTotal multiplica precio por cantidad', () => {
      const carrito = [{ ...corona, cantidad: 2 }, { ...urna, cantidad: 1 }];
      expect(calcularTotal(carrito)).toBe(75000 * 2 + 380000);
    });

    it('calcularTotal de un carrito vacío es 0', () => {
      expect(calcularTotal([])).toBe(0);
    });

    it('contarUnidades suma las cantidades de todos los productos', () => {
      expect(contarUnidades([{ ...corona, cantidad: 2 }, { ...urna, cantidad: 3 }])).toBe(5);
    });

    it('formatearPrecio usa el formato de pesos chilenos', () => {
      const texto = formatearPrecio(1250000);
      expect(texto).toContain('$');
      expect(texto).toContain('1.250.000');
    });
  });

  // aquí usamos mocks: reemplazamos localStorage con spyOn para no depender
  // de lo que haya guardado en el navegador
  describe('localStorage (con mocks)', () => {
    it('leerCarrito devuelve lo guardado en localStorage', () => {
      const getItem = spyOn(Storage.prototype, 'getItem').and.returnValue(
        JSON.stringify([{ ...corona, cantidad: 1 }])
      );

      const carrito = leerCarrito();

      expect(getItem).toHaveBeenCalledWith(CLAVE_CARRITO);
      expect(carrito.length).toBe(1);
      expect(carrito[0].nombre).toBe('Corona');
    });

    it('leerCarrito devuelve [] si no hay nada guardado', () => {
      spyOn(Storage.prototype, 'getItem').and.returnValue(null);
      expect(leerCarrito()).toEqual([]);
    });

    it('leerCarrito devuelve [] si lo guardado está corrupto', () => {
      spyOn(Storage.prototype, 'getItem').and.returnValue('{esto no es json');
      expect(leerCarrito()).toEqual([]);
    });

    it('guardarCarrito guarda el JSON y avisa con el evento carrito-actualizado', () => {
      const setItem = spyOn(Storage.prototype, 'setItem');
      const dispatch = spyOn(window, 'dispatchEvent');
      const carrito = [{ ...urna, cantidad: 1 }];

      guardarCarrito(carrito);

      expect(setItem).toHaveBeenCalledWith(CLAVE_CARRITO, JSON.stringify(carrito));
      expect(dispatch).toHaveBeenCalled();
      expect(dispatch.calls.mostRecent().args[0].type).toBe('carrito-actualizado');
    });
  });
});
