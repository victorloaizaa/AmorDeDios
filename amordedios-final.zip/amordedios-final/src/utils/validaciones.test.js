import { validarNombre, validarCorreo, validarTelefono, validarPlan } from './validaciones';

describe('utils/validaciones - reglas del formulario de contacto', () => {
  it('nombre: pide mínimo 3 caracteres sin contar espacios', () => {
    expect(validarNombre('Al')).toContain('mínimo 3 caracteres');
    expect(validarNombre('   ')).not.toBe('');
    expect(validarNombre('Ana')).toBe('');
  });

  it('correo: acepta correos con @ y dominio, rechaza los mal escritos', () => {
    expect(validarCorreo('maria@correo.cl')).toBe('');
    expect(validarCorreo('maria@correo')).not.toBe('');
    expect(validarCorreo('mariacorreo.cl')).not.toBe('');
    expect(validarCorreo('')).toContain('correo válido');
  });

  it('teléfono: acepta celulares chilenos con o sin +56 y espacios', () => {
    expect(validarTelefono('+56 9 1234 5678')).toBe('');
    expect(validarTelefono('56912345678')).toBe('');
    expect(validarTelefono('9 1234 5678')).toBe('');
  });

  it('teléfono: rechaza fijos, números cortos y de otros países', () => {
    expect(validarTelefono('+56 2 1234 5678')).not.toBe('');
    expect(validarTelefono('9123')).not.toBe('');
    expect(validarTelefono('+54 9 1234 5678')).not.toBe('');
  });

  it('plan: es obligatorio elegir una opción', () => {
    expect(validarPlan('')).toContain('Selecciona');
    expect(validarPlan('premium')).toBe('');
  });
});
