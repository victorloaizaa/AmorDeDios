import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Servicios from './pages/Servicios';
import Sucursales from './pages/Sucursales';

describe('App - renderizado de las vistas principales', () => {

  it('1. Debe renderizar el menú de navegación correctamente', () => {
    render(
      <MemoryRouter>
        <Navbar />
      </MemoryRouter>
    );
    expect(screen.getByRole('navigation')).toBeDefined();
  });

  it('2. Debe mostrar la opción principal en el Navbar', () => {
    render(
      <MemoryRouter>
        <Navbar />
      </MemoryRouter>
    );
    expect(screen.getAllByText(/Inicio/i).length).toBeGreaterThan(0);
  });

  it('3. Debe contener el enlace hacia la sección de Servicios', () => {
    render(
      <MemoryRouter>
        <Navbar />
      </MemoryRouter>
    );
    expect(screen.getAllByText(/Servicios/i).length).toBeGreaterThan(0);
  });

  it('4. Debe renderizar el título principal en la Home', () => {
    render(
      <MemoryRouter>
        <Home />
      </MemoryRouter>
    );
    expect(screen.getByRole('heading', { level: 1 })).toBeDefined();
  });

  it('5. Debe renderizar el pie de página corporativo', () => {
    render(
      <MemoryRouter>
        <Footer />
      </MemoryRouter>
    );
    expect(screen.getByRole('contentinfo')).toBeDefined();
  });

  it('6. Debe renderizar la vista de Servicios', () => {
    const { container } = render(
      <MemoryRouter>
        <Servicios />
      </MemoryRouter>
    );
    expect(container).toBeDefined();
  });

  it('7. Debe mostrar la sucursal Las Galaxias (Cerrillos)', () => {
    render(
      <MemoryRouter>
        <Sucursales />
      </MemoryRouter>
    );
    expect(screen.getByText(/Las Galaxias/i)).toBeDefined();
  });

  it('8. Debe indicar la disponibilidad 24/7', () => {
    render(
      <MemoryRouter>
        <Sucursales />
      </MemoryRouter>
    );
    expect(screen.getByText(/Atención Telefónica 24\/7/i)).toBeDefined();
  });

  it('9. Debe contener el botón de contacto principal', () => {
    render(
      <MemoryRouter>
        <Sucursales />
      </MemoryRouter>
    );
    expect(screen.getByText(/CONTACTAR AHORA/i)).toBeDefined();
  });

  it('10. Debe cargar el contenedor principal de la vista Home', () => {
    const { container } = render(
      <MemoryRouter>
        <Home />
      </MemoryRouter>
    );
    expect(container.firstChild).not.toBeNull();
  });

});