import React from 'react';
import { Link } from 'react-router-dom';

const ANIO_ACTUAL = new Date().getFullYear();

export default function Footer() {
  return (
    <footer className="footer-mini">
      <div className="footer-linea"></div>
      {/* en celular queda todo centrado y apilado */}
      <div className="contenedor footer-contenido-mini d-flex flex-column flex-md-row flex-wrap justify-content-between align-items-center gap-3 text-center text-md-start">
        <div className="footer-info d-flex flex-column">
          <strong>Funeraria Amor de Dios</strong>
          <span>Atención las 24 horas: +56 9 8765 4321</span>
        </div>

        <nav className="footer-nav nav flex-wrap justify-content-center gap-3" aria-label="Enlaces del pie de página">
          <Link to="/">Inicio</Link>
          <Link to="/nosotros">Nosotros</Link>
          <Link to="/servicios">Servicios</Link>
          <Link to="/tienda">Planes</Link>
          <Link to="/sucursales">Sucursales</Link>
          <Link to="/contacto">Contacto</Link>
        </nav>

        <div className="footer-copy">
          © {ANIO_ACTUAL} Todos los derechos reservados.
        </div>
      </div>
    </footer>
  );
}