import React from 'react';
import { formatearPrecio } from '../utils/carrito';

// Una fila del carrito. Recibe el item y las funciones para cambiar la
// cantidad o quitarlo; el carrito completo lo maneja la página Carrito.
export default function ItemCarrito({ item, onCambiarCantidad, onEliminar }) {
  return (
    <li className="list-group-item px-0 py-3">
      <div className="row align-items-center g-3">
        <div className="col-12 col-sm-6 d-flex align-items-center gap-3">
          <img
            src={item.imagen}
            alt={item.nombre}
            className="rounded img-carrito"
            onError={(e) => { e.target.src = '/img/arregloFloral.jpg'; }}
          />
          <div>
            <span className="badge bg-warning text-dark">{item.categoria || 'PLANES'}</span>
            <h3 className="h6 my-1">{item.nombre}</h3>
            <p className="mb-0 fw-bold">{formatearPrecio(item.precio)}</p>
          </div>
        </div>

        <div className="col-6 col-sm-3">
          <div className="input-group input-group-sm" role="group" aria-label={`Cantidad de ${item.nombre}`}>
            <button type="button" className="btn btn-outline-secondary" aria-label="Restar uno" onClick={() => onCambiarCantidad(item.id, -1)}>-</button>
            <span className="input-group-text bg-white fw-bold" data-testid="cantidad">{item.cantidad}</span>
            <button type="button" className="btn btn-outline-secondary" aria-label="Sumar uno" onClick={() => onCambiarCantidad(item.id, 1)}>+</button>
          </div>
        </div>

        <div className="col-6 col-sm-3 d-flex align-items-center justify-content-end gap-2">
          <span className="fw-bold">{formatearPrecio(item.precio * item.cantidad)}</span>
          <button
            type="button"
            className="btn btn-sm btn-outline-danger"
            aria-label={`Quitar ${item.nombre}`}
            onClick={() => onEliminar(item.id)}
          >
            ✕
          </button>
        </div>
      </div>
    </li>
  );
}
