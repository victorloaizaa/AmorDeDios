import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import ServicioCard from './ServicioCard';

// ServicioCard usa <Link>, que necesita un router. MemoryRouter es un router
// "falso" que funciona en memoria, sirve como mock del router del navegador.
const renderCard = (props) =>
  render(
    <MemoryRouter>
      <ServicioCard titulo="Cremación" descripcion="Texto de prueba" link="/cremacion" {...props} />
    </MemoryRouter>
  );

describe('ServicioCard - props', () => {
  it('versión destacada: muestra badge y botón hacia el link', () => {
    renderCard({ badge: 'Certificado', destacado: true });

    expect(screen.getByText('Certificado')).toBeDefined();
    const enlace = screen.getByRole('link', { name: /Ver detalles del servicio/ });
    expect(enlace.getAttribute('href')).toBe('/cremacion');
  });

  it('versión simple: sin badge y con el texto "Consultar más información"', () => {
    renderCard({ badge: 'Certificado' });

    expect(screen.queryByText('Certificado')).toBeNull();
    expect(screen.getByRole('link', { name: /Consultar más información/ })).toBeDefined();
  });
});
