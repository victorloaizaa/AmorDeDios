import { render, screen, fireEvent } from '@testing-library/react';
import ProductoCard from './ProductoCard';

const producto = {
  id: 'plan-prueba',
  nombre: 'Plan de Prueba',
  categoria: 'planes',
  precio: 450000,
  imagen: '/img/presentacion1.jpg',
  descripcion: 'Descripción del plan',
  detalles: ['Urna de pino', 'Carroza', 'Capilla ardiente'],
};

describe('ProductoCard - props', () => {
  it('muestra los datos que recibe por props', () => {
    render(<ProductoCard producto={producto} onAgregar={() => {}} />);

    expect(screen.getByRole('heading', { name: 'Plan de Prueba' })).toBeDefined();
    expect(screen.getByText('PLANES')).toBeDefined();
    expect(screen.getByText(/450\.000/)).toBeDefined();
    expect(screen.getByAltText('Plan de Prueba')).toBeDefined();
  });

  it('dibuja un elemento de la lista por cada detalle', () => {
    render(<ProductoCard producto={producto} onAgregar={() => {}} />);
    expect(screen.getAllByRole('listitem').length).toBe(3);
  });

  it('no muestra lista si el producto no trae detalles', () => {
    render(<ProductoCard producto={{ ...producto, detalles: undefined }} onAgregar={() => {}} />);
    expect(screen.queryAllByRole('listitem').length).toBe(0);
  });

  it('al hacer clic llama a onAgregar con el producto (spy)', () => {
    const onAgregar = jasmine.createSpy('onAgregar');
    render(<ProductoCard producto={producto} onAgregar={onAgregar} />);

    fireEvent.click(screen.getByRole('button', { name: 'Agregar al Plan' }));

    expect(onAgregar).toHaveBeenCalledTimes(1);
    expect(onAgregar).toHaveBeenCalledWith(producto);
  });

  it('el texto del botón se puede cambiar con la prop textoBoton', () => {
    render(<ProductoCard producto={producto} onAgregar={() => {}} textoBoton="Reservar" />);
    expect(screen.getByRole('button', { name: 'Reservar' })).toBeDefined();
  });
});
