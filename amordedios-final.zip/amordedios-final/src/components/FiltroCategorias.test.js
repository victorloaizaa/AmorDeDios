import { render, screen, fireEvent } from '@testing-library/react';
import FiltroCategorias from './FiltroCategorias';

const categorias = [
  { id: 'planes', texto: 'Planes' },
  { id: 'urnas', texto: 'Urnas' },
  { id: 'flores', texto: 'Flores' },
];

describe('FiltroCategorias - props y eventos', () => {
  it('crea un botón por categoría', () => {
    render(<FiltroCategorias categorias={categorias} activa="planes" onCambiar={() => {}} />);
    expect(screen.getAllByRole('button').length).toBe(3);
  });

  it('marca como activo solo el botón de la categoría activa', () => {
    render(<FiltroCategorias categorias={categorias} activa="urnas" onCambiar={() => {}} />);

    expect(screen.getByRole('button', { name: 'Urnas' }).className).toContain('activo');
    expect(screen.getByRole('button', { name: 'Planes' }).className).not.toContain('activo');
  });

  it('avisa al padre con onCambiar y el id de la categoría', () => {
    const onCambiar = jasmine.createSpy('onCambiar');
    render(<FiltroCategorias categorias={categorias} activa="planes" onCambiar={onCambiar} />);

    fireEvent.click(screen.getByRole('button', { name: 'Flores' }));

    expect(onCambiar).toHaveBeenCalledWith('flores');
  });
});
