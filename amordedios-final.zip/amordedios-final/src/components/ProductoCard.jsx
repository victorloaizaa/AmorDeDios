import React from 'react';
import { formatearPrecio } from '../utils/carrito';

// Tarjeta de un plan o producto de la tienda.
// props:
//  - producto: objeto con nombre, categoria, precio, imagen, descripcion y detalles
//  - onAgregar: función que se llama al apretar el botón (la manda Tienda)
//  - textoBoton: opcional, por defecto "Agregar al Plan"
export default function ProductoCard({ producto, onAgregar, textoBoton = 'Agregar al Plan' }) {
  const { nombre, categoria, precio, imagen, descripcion, detalles = [] } = producto;

  return (
    <div className="card h-100 shadow-sm border-0 tarjeta-producto-bs">
      <img src={imagen} alt={nombre} loading="lazy" className="card-img-top" />
      <div className="card-body d-flex flex-column">
        <span className="badge bg-warning text-dark align-self-start mb-2">{categoria.toUpperCase()}</span>
        <h3 className="card-title h5">{nombre}</h3>
        <p className="card-text small text-muted">{descripcion}</p>

        {detalles.length > 0 && (
          <ul className="list-unstyled small mb-3">
            {detalles.map((detalle) => (
              <li key={detalle}>• {detalle}</li>
            ))}
          </ul>
        )}

        <div className="mt-auto">
          <p className="fs-5 fw-bold mb-2">{formatearPrecio(precio)}</p>
          <button type="button" className="btn btn-dark w-100" onClick={() => onAgregar(producto)}>
            {textoBoton}
          </button>
        </div>
      </div>
    </div>
  );
}
