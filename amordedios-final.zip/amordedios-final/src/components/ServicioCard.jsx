import React from 'react';
import { Link } from 'react-router-dom';

// Tarjeta de servicio. Se usa en la página Servicios para los principales y
// los complementarios; con la prop "destacado" cambia el estilo.
export default function ServicioCard({ titulo, descripcion, link, badge, destacado = false }) {
  if (destacado) {
    return (
      <div className="card h-100 border-0 shadow-sm tarjeta-servicio">
        <div className="card-body d-flex flex-column p-4">
          {badge && <span className="badge rounded-pill badge-servicio align-self-start mb-3">{badge}</span>}
          <h3 className="card-title h4 titulo-servicio">{titulo}</h3>
          <p className="card-text text-secondary mb-4">{descripcion}</p>
          <Link to={link} className="btn btn-dark text-warning border-warning fw-bold mt-auto">
            Ver detalles del servicio →
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="card h-100 shadow-sm border-warning-subtle">
      <div className="card-body d-flex flex-column p-4">
        <h3 className="card-title h5">{titulo}</h3>
        <p className="card-text text-secondary small mb-4">{descripcion}</p>
        <Link to={link} className="link-dark fw-bold text-decoration-none mt-auto">
          Consultar más información →
        </Link>
      </div>
    </div>
  );
}
