import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { leerCarrito, contarUnidades } from '../utils/carrito';

// links del submenú de Servicios
const SUBSERVICIOS = [
  { to: '/prearreglos', texto: 'Prearreglos Funerarios' },
  { to: '/velatorio-capilla', texto: 'Velatorios y Capillas' },
  { to: '/cremacion', texto: 'Cremación y Cinerario' },
  { to: '/traslados', texto: 'Traslados Nacionales e Internacionales' },
  { to: '/tramites-documentacion', texto: 'Trámites y Documentación' },
  { to: '/acompanamiento-espiritual', texto: 'Acompañamiento Espiritual' },
  { to: '/contencion-emocional', texto: 'Contención Emocional' },
  { to: '/convenios-seguros', texto: 'Convenios y Seguros' },
];

export default function Navbar() {
  const [cantidadCarrito, setCantidadCarrito] = useState(() => contarUnidades(leerCarrito()));
  const [menuServiciosAbierto, setMenuServiciosAbierto] = useState(false);
  const [menuMovilAbierto, setMenuMovilAbierto] = useState(false); // botón hamburguesa
  const location = useLocation();

  // el contador se actualiza cuando cambia el carrito (en esta pestaña o en otra)
  useEffect(() => {
    const actualizarContador = () => setCantidadCarrito(contarUnidades(leerCarrito()));
    window.addEventListener('carrito-actualizado', actualizarContador);
    window.addEventListener('storage', actualizarContador);
    return () => {
      window.removeEventListener('carrito-actualizado', actualizarContador);
      window.removeEventListener('storage', actualizarContador);
    };
  }, []);

  // al cambiar de página se cierran los menús
  useEffect(() => {
    setMenuServiciosAbierto(false);
    setMenuMovilAbierto(false);
  }, [location]);

  const claseEnlace = ({ isActive }) => `nav-link${isActive ? ' active' : ''}`;

  return (
    <header className="site-header">
      {/* navbar-expand-lg: desde 992px se ve el menú completo, abajo de eso queda la hamburguesa */}
      <nav className="navbar navbar-expand-lg navbar-dark" aria-label="Menú principal">
        <div className="container-fluid px-3 px-lg-4">

          {/* logo */}
          <Link to="/" className="navbar-brand d-flex align-items-center gap-2">
            <img
              src="/img/logoFuneraria.jpg"
              alt="Amor de Dios"
              className="logo-navbar rounded"
              onError={(e) => { e.target.style.display = 'none'; }}
            />
            <span className="eslogan-navbar">25/8 contigo</span>
          </Link>

          {/* hamburguesa (solo en celular/tablet) */}
          <button
            className="navbar-toggler"
            type="button"
            aria-controls="menu-principal"
            aria-expanded={menuMovilAbierto}
            aria-label="Abrir menú de navegación"
            onClick={() => setMenuMovilAbierto(!menuMovilAbierto)}
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className={`collapse navbar-collapse${menuMovilAbierto ? ' show' : ''}`} id="menu-principal">
            <ul className="navbar-nav ms-auto align-items-lg-center gap-lg-2">
              <li className="nav-item">
                <NavLink to="/" end className={claseEnlace}>Inicio</NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/nosotros" className={claseEnlace}>Nosotros</NavLink>
              </li>

              {/* dropdown de servicios, lo abrimos con el estado en vez del JS de bootstrap */}
              <li
                className="nav-item dropdown"
                onMouseEnter={() => setMenuServiciosAbierto(true)}
                onMouseLeave={() => setMenuServiciosAbierto(false)}
              >
                <div className="d-flex align-items-center">
                  <NavLink to="/servicios" className={claseEnlace}>Servicios</NavLink>
                  <button
                    type="button"
                    className="btn btn-link dropdown-toggle text-warning p-1"
                    aria-expanded={menuServiciosAbierto}
                    aria-label="Ver subservicios"
                    onClick={() => setMenuServiciosAbierto(!menuServiciosAbierto)}
                  ></button>
                </div>
                <ul className={`dropdown-menu dropdown-menu-dark submenu-servicios${menuServiciosAbierto ? ' show' : ''}`}>
                  <li>
                    <Link className="dropdown-item fw-bold text-warning" to="/servicios">Ver todos los servicios</Link>
                  </li>
                  <li><hr className="dropdown-divider" /></li>
                  {SUBSERVICIOS.map((s) => (
                    <li key={s.to}>
                      <Link className="dropdown-item" to={s.to}>{s.texto}</Link>
                    </li>
                  ))}
                </ul>
              </li>

              <li className="nav-item">
                <NavLink to="/tienda" className={claseEnlace}>Planes Funerarios</NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/sucursales" className={claseEnlace}>Sucursales</NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/contacto" className={claseEnlace}>Contacto</NavLink>
              </li>
              <li className="nav-item">
                <NavLink to="/login" className={claseEnlace}>Iniciar Sesión</NavLink>
              </li>

              {/* carrito con contador */}
              <li className="nav-item mt-2 mt-lg-0">
                <Link to="/carrito" className="btn btn-outline-warning rounded-pill btn-sm d-inline-flex align-items-center gap-2">
                  <span>🛒</span>
                  <span>Carrito</span>
                  {cantidadCarrito > 0 && (
                    <span className="badge rounded-pill bg-warning text-dark">{cantidadCarrito}</span>
                  )}
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
  );
}
