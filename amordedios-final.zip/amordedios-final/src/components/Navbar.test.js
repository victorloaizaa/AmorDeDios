import { render, screen, fireEvent, act } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Navbar from './Navbar';

const renderNavbar = () =>
  render(
    <MemoryRouter>
      <Navbar />
    </MemoryRouter>
  );

describe('Navbar - estado del menú y contador del carrito', () => {
  it('el botón hamburguesa abre y cierra el menú (clase show)', () => {
    spyOn(Storage.prototype, 'getItem').and.returnValue(null);
    const { container } = renderNavbar();
    const boton = screen.getByRole('button', { name: 'Abrir menú de navegación' });
    const menu = container.querySelector('#menu-principal');

    expect(menu.className).not.toContain('show');
    fireEvent.click(boton);
    expect(menu.className).toContain('show');
    expect(boton.getAttribute('aria-expanded')).toBe('true');
    fireEvent.click(boton);
    expect(menu.className).not.toContain('show');
  });

  it('el submenú de servicios se abre al pasar el mouse', () => {
    spyOn(Storage.prototype, 'getItem').and.returnValue(null);
    const { container } = renderNavbar();
    const submenu = container.querySelector('.submenu-servicios');

    fireEvent.mouseEnter(submenu.parentElement);
    expect(submenu.className).toContain('show');
    fireEvent.mouseLeave(submenu.parentElement);
    expect(submenu.className).not.toContain('show');
  });

  it('muestra la cantidad de productos del carrito (localStorage simulado)', () => {
    spyOn(Storage.prototype, 'getItem').and.returnValue(
      JSON.stringify([{ id: 'a', cantidad: 2 }, { id: 'b', cantidad: 1 }])
    );
    renderNavbar();

    expect(screen.getByRole('link', { name: /Carrito/ }).textContent).toContain('3');
  });

  it('no muestra contador si el carrito está vacío', () => {
    spyOn(Storage.prototype, 'getItem').and.returnValue(null);
    const { container } = renderNavbar();
    expect(container.querySelector('.badge')).toBeNull();
  });

  it('actualiza el contador cuando llega el evento carrito-actualizado', () => {
    const getItem = spyOn(Storage.prototype, 'getItem').and.returnValue(null);
    renderNavbar();

    getItem.and.returnValue(JSON.stringify([{ id: 'a', cantidad: 4 }]));
    act(() => {
      window.dispatchEvent(new Event('carrito-actualizado'));
    });

    expect(screen.getByRole('link', { name: /Carrito/ }).textContent).toContain('4');
  });
});
