import React from 'react';

// Botones para filtrar la tienda.
// El estado (qué categoría está activa) vive en Tienda; este componente solo
// lo muestra y avisa del cambio con onCambiar.
export default function FiltroCategorias({ categorias, activa, onCambiar }) {
  return (
    <div className="filtros-tienda d-flex flex-wrap gap-2 mb-4" role="group" aria-label="Filtrar por categoría">
      {categorias.map((cat) => (
        <button
          key={cat.id}
          type="button"
          className={`btn rounded-pill px-4 filtro-boton ${activa === cat.id ? 'btn-dark activo' : 'btn-outline-dark'}`}
          aria-pressed={activa === cat.id}
          onClick={() => onCambiar(cat.id)}
        >
          {cat.texto}
        </button>
      ))}
    </div>
  );
}
