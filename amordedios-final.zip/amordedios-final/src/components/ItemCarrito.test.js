import { render, screen, fireEvent } from '@testing-library/react';
import ItemCarrito from './ItemCarrito';

const item = { id: 'urna', nombre: 'Urna Huasco', categoria: 'URNAS', precio: 100000, cantidad: 2, imagen: '/img/x.jpg' };

// ItemCarrito va dentro de un <ul>, por eso lo envolvemos
const renderItem = (props) =>
  render(
    <ul>
      <ItemCarrito item={item} onCambiarCantidad={() => {}} onEliminar={() => {}} {...props} />
    </ul>
  );

describe('ItemCarrito - props y eventos', () => {
  it('muestra la cantidad y el subtotal (precio x cantidad)', () => {
    renderItem();
    expect(screen.getByTestId('cantidad').textContent).toBe('2');
    expect(screen.getByText(/200\.000/)).toBeDefined();
  });

  it('los botones + y - llaman a onCambiarCantidad con el id y +1 / -1', () => {
    const onCambiarCantidad = jasmine.createSpy('onCambiarCantidad');
    renderItem({ onCambiarCantidad });

    fireEvent.click(screen.getByRole('button', { name: 'Sumar uno' }));
    fireEvent.click(screen.getByRole('button', { name: 'Restar uno' }));

    expect(onCambiarCantidad.calls.argsFor(0)).toEqual(['urna', 1]);
    expect(onCambiarCantidad.calls.argsFor(1)).toEqual(['urna', -1]);
  });

  it('el botón quitar llama a onEliminar con el id', () => {
    const onEliminar = jasmine.createSpy('onEliminar');
    renderItem({ onEliminar });

    fireEvent.click(screen.getByRole('button', { name: 'Quitar Urna Huasco' }));

    expect(onEliminar).toHaveBeenCalledWith('urna');
  });

  it('si la imagen no carga pone una imagen de reemplazo', () => {
    renderItem();
    const img = screen.getByAltText('Urna Huasco');

    fireEvent.error(img);

    expect(img.getAttribute('src')).toBe('/img/arregloFloral.jpg');
  });
});
