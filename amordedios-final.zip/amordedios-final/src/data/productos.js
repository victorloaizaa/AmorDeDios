// Catálogo de la tienda: planes, urnas y flores
// (cuando tengamos backend esto vendrá de la API)
export const PRODUCTOS = [
  // --- PLANES FUNERARIOS ---
  {
    id: "plan-basico",
    nombre: "Plan Básico Tradicional",
    categoria: "planes",
    precio: 450000,
    imagen: "/img/presentacion1.jpg",
    descripcion: "Servicio esencial y digno para familias que buscan una opción económica.",
    detalles: [
      "Urna básica de pino barnizado",
      "Trámites legales y registro civil",
      "Traslado inicial dentro de la Región Metropolitana",
      "Capilla ardiente estándar",
      "Carroza para el sepelio"
    ]
  },
  {
    id: "plan-basico-terciado",
    nombre: "Plan Básico - Urna Plana Terciado",
    categoria: "planes",
    precio: 590000,
    imagen: "/img/Urna plana terciado.jpeg",
    descripcion: "Servicio esencial con acompañamiento completo y digno.",
    detalles: [
      "Urna Plana Terciado de terminación fina",
      "Trámites legales y registro civil",
      "Traslado inicial y carroza para el sepelio",
      "Asesoría y coordinación 24/7"
    ]
  },
  {
    id: "plan-intermedio",
    nombre: "Plan Familiar Superior",
    categoria: "planes",
    precio: 780000,
    imagen: "/img/presentacion2.jpg",
    descripcion: "Cobertura completa con atención personalizada y detalles adicionales.",
    detalles: [
      "Urna de madera noble barnizada",
      "Capilla ardiente completa con iluminación",
      "Trámites legales y certificación de fallecimiento",
      "Carroza panorámica e instalador",
      "Arreglo floral superior",
      "Bus de acompañamiento para la familia"
    ]
  },
  {
    id: "plan-tradicional-pino",
    nombre: "Plan Tradicional - Urna Pino Rebalsada",
    categoria: "planes",
    precio: 890000,
    imagen: "/img/Urna pino rebalsada.jpeg",
    descripcion: "Nuestro plan más solicitado para velatorio tradicional.",
    detalles: [
      "Urna Pino Rebalsada con detalles tallados",
      "Capilla ardiente e iluminación para velatorio",
      "Arreglo floral superior de cortesía",
      "Trámites legales y carroza panorámica"
    ]
  },
  {
    id: "plan-cremacion",
    nombre: "Plan Integral de Cremación",
    categoria: "planes",
    precio: 980000,
    imagen: "/img/cremacion.jpg",
    descripcion: "Proceso certificado completo con ceremonia de despedida previa.",
    detalles: [
      "Urna especial para cremación",
      "Gestión y permisos de cremación",
      "Derechos de cinerario",
      "Ánfora de cinerario a elección",
      "Velatorio previo en capilla",
      "Traslado al cinerario"
    ]
  },
  {
    id: "plan-clasico-terciado",
    nombre: "Plan Clásico - Urna Terciado Rebalsada",
    categoria: "planes",
    precio: 1150000,
    imagen: "/img/Urna terciado rebalsada.jpeg",
    descripcion: "Elegancia y presencia distinguida en madera seleccionada.",
    detalles: [
      "Urna Terciado Rebalsada de alta terminación",
      "Cinerario o Urna para cenizas disponible",
      "Capilla ecuménica completa con ciriales",
      "Carroza ceremonial y auto de acompañamiento"
    ]
  },
  {
    id: "plan-premium",
    nombre: "Plan Honor Imperial",
    categoria: "planes",
    precio: 1250000,
    imagen: "/img/presentacion3.jpg",
    descripcion: "Servicio de máxima distinción con todos los requerimientos cubiertos.",
    detalles: [
      "Urna de madera fina tallada con finas terminaciones",
      "Capilla ecuménica completa",
      "Gestión integral de trámites legales",
      "Carroza de gala y vehículo VIP",
      "Servicio floral completo y libro de condolencias",
      "Publicación de obituario digital",
      "Asesoría personalizada 24/7"
    ]
  },
  {
    id: "plan-selegancia-olimpia",
    nombre: "Plan Superior - Urna Olimpia Pino",
    categoria: "planes",
    precio: 1490000,
    imagen: "/img/Urna Olimpia pino.jpeg",
    descripcion: "Acabado caoba profundo con tallado y herrajes nobles.",
    detalles: [
      "Urna Olimpia Pino de diseño exclusivo",
      "Cortejo ceremonial con velatorio en capilla",
      "Arreglos florales prémium e impresos de condolencia",
      "Gestión integral de sepultación o cremación"
    ]
  },
  {
    id: "plan-imperial-huasco",
    nombre: "Plan Imperial - Urna Huasco",
    categoria: "planes",
    precio: 1890000,
    imagen: "/img/Urna Huasco.jpeg",
    descripcion: "Máxima distinción y solidez para un homenaje memorable.",
    detalles: [
      "Urna Huasco en madera noble de alto brillo",
      "Servicio de protocolo y atención personalizada constante",
      "Servicio floral completo y libro de condolencias",
      "Carroza de gala y van familiar incluida"
    ]
  },

  // --- URNAS Y ÁNFORAS ---
  {
    id: "urna-huasco-ind",
    nombre: "Urna Modelo Huasco",
    categoria: "urnas",
    precio: 950000,
    imagen: "/img/Urna Huasco.jpeg",
    descripcion: "Urna de madera noble barnizada de alta gama.",
    detalles: ["Diseño curvo sobrio", "Herrajes de bronce", "Acolchado interior en raso"]
  },
  {
    id: "urna-olimpia-ind",
    nombre: "Urna Modelo Olimpia Pino",
    categoria: "urnas",
    precio: 720000,
    imagen: "/img/Urna Olimpia pino.jpeg",
    descripcion: "Modelo señorial con tono caoba oscuro.",
    detalles: ["Tallado artesanal", "Tapa superior rebajada", "Interior de raso blanco"]
  },
  {
    id: "urna-pino-rebalsada-ind",
    nombre: "Urna Modelo Pino Rebalsada",
    categoria: "urnas",
    precio: 520000,
    imagen: "/img/Urna pino rebalsada.jpeg",
    descripcion: "Modelo clásico en pino con acabado brillante.",
    detalles: ["Terminación tradicional", "Manillas metálicas reinforced", "Interior acogedor"]
  },
  {
    id: "urna-plana-terciado-ind",
    nombre: "Urna Modelo Plana Terciado",
    categoria: "urnas",
    precio: 380000,
    imagen: "/img/Urna plana terciado.jpeg",
    descripcion: "Urna plana sobria de diseño accesible.",
    detalles: ["Líneas rectas elegantes", "Tono nogal cálido", "Interior acolchado"]
  },
  {
    id: "anfora-three-birds",
    nombre: "Ánfora Cineraria Three Birds (Aves Doradas)",
    categoria: "urnas",
    precio: 220000,
    imagen: "/img/anfora three birds.jpg",
    descripcion: "Ánfora de cerámica esmaltada blanca con detalles en bronce de aves en vuelo.",
    detalles: ["Acabado en loza brillante y bronce noble", "Símbolo de paz y elevación espiritual", "Cierre hermético de alta seguridad"]
  },
  {
    id: "anfora-paisaje",
    nombre: "Ánfora Cineraria Naturaleza y Bosque",
    categoria: "urnas",
    precio: 195000,
    imagen: "/img/anfora paisaje.jpg",
    descripcion: "Ánfora metálica decorativa grabada con motivos de bosque y naturaleza.",
    detalles: ["Material metálico con bordes cromaticos pulidos", "Diseño artístico de paisaje natural", "Resistente y duradera"]
  },
  {
    id: "anfora-biodegradable",
    nombre: "Ánfora Cineraria Ecológica Biodegradable",
    categoria: "urnas",
    precio: 160000,
    imagen: "/img/anfora biodegradable.jpg",
    descripcion: "Ánfora de componentes naturales diseñada para reintegrarse con la tierra o el mar.",
    detalles: ["100% ecológica y biodegradable", "Cinturón de fibra natural decorativo", "Ideal para ceremonias en la naturaleza"]
  },
  {
    id: "anforas-coleccion",
    nombre: "Colección Completa de Ánforas de Cremación",
    categoria: "urnas",
    precio: 180000,
    imagen: "/img/foto publicitaria anforas.jpeg",
    descripcion: "Variedad de ánforas en bronce, madera, cerámica y mármol.",
    detalles: ["Grabado personalizado de nombre y fechas", "Asesoría en la elección del material", "Diferentes estilos y terminaciones"]
  },

  // --- FLORES Y ARREGLOS FLORALES ---
  {
    id: "corona-arreglo-floral",
    nombre: "Corona Ceremonial de Flores",
    categoria: "flores",
    precio: 75000,
    imagen: "/img/corona arreglo floral.webp",
    descripcion: "Corona redonda ceremonial con rosas y lirios frescos.",
    detalles: ["Flores frescas seleccionadas", "Cinta personalizada con condolencia", "Atril de madera incluido"]
  },
  {
    id: "cubre-urna-arreglo",
    nombre: "Arreglo Cubre Urna de Rosas Blancas",
    categoria: "flores",
    precio: 85000,
    imagen: "/img/cubre urna arreglo floral.webp",
    descripcion: "Manto floral alargado de rosas blancas diseñado para posar sobre la urna.",
    detalles: ["Rosas blancas prémium", "Base húmeda para conservación", "Diseño simétrico de máxima elegancia"]
  },
  {
    id: "pie-de-urna-arreglo",
    nombre: "Arreglo Pie de Urna en Cascada",
    categoria: "flores",
    precio: 65000,
    imagen: "/img/pie de urna arreglo.webp",
    descripcion: "Composición en altura con lilium y rosas para la base del altar.",
    detalles: ["Lilium y rosas blancas/marfil", "Follaje fino de acompañamiento", "Estructura firme para capilla"]
  }
];
