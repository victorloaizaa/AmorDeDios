import React from 'react';

export default function VelatorioCapilla() {
  return (
    <main>
      <section className="hero">
        <div className="contenedor">
          <div>
            <p className="hero-eyebrow">Servicios</p>
            <h1>Velatorio y Capilla Ardiente</h1>
            <p>
              Espacios acondicionados con la mayor sobriedad, tranquilidad y confort para que las familias y seres queridos puedan brindar su último adiós.
            </p>
          </div>
          <div className="hero-imagen">
            <img src="/img/velacion.jpg" alt="Velatorio y Capilla" />
          </div>
        </div>
      </section>

      <section className="seccion">
        <div className="contenedor">
          <div className="seccion-titulo">
            <h2>Instalaciones y Capillas</h2>
          </div>
          <div className="row row-cols-1 row-cols-md-2 g-4">
            <div className="col">
              <div className="tarjeta-servicio h-100">
                <img src="/img/velacion2.jpg" alt="Capilla Ardiente" style={{ width: '100%', borderRadius: '8px', marginBottom: '1rem' }} />
                <h3>Capilla Ardiente Completa</h3>
                <p>Montaje ceremonial con ciriales,porta flores y acondicionamiento estético que entrega un ambiente de paz y solemnidad.</p>
              </div>
            </div>
            <div className="col">
              <div className="tarjeta-servicio h-100">
                <img src="/img/fachada funeraria.jpeg" alt="Atención Presencial" style={{ width: '100%', borderRadius: '8px', marginBottom: '1rem' }} />
                <h3>Atención y Acompañamiento</h3>
                <p>Personal protocolar permanente para asistir a los familiares en todo momento durante el velatorio.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}