import { render, screen, fireEvent } from '@testing-library/react';
import Login from './Login';

describe('Login - ingreso y registro', () => {
  it('parte en modo "Iniciar Sesión" con correo y contraseña', () => {
    render(<Login />);

    expect(screen.getByRole('heading', { name: 'Iniciar Sesión' })).toBeDefined();
    expect(screen.getByLabelText('Correo Electrónico')).toBeDefined();
    expect(screen.queryByLabelText('Nombre Completo')).toBeNull();
  });

  it('al pasar a registro aparecen los campos de nombre y teléfono', () => {
    render(<Login />);

    fireEvent.click(screen.getByRole('button', { name: 'Regístrate aquí' }));

    expect(screen.getByRole('heading', { name: 'Crear una Cuenta' })).toBeDefined();
    expect(screen.getByLabelText('Nombre Completo')).toBeDefined();
    expect(screen.getByLabelText('Teléfono de Contacto')).toBeDefined();
  });

  it('al registrarse muestra el mensaje y vuelve a iniciar sesión (mock de alert)', () => {
    const alerta = spyOn(window, 'alert');
    render(<Login />);

    fireEvent.click(screen.getByRole('button', { name: 'Regístrate aquí' }));
    fireEvent.change(screen.getByLabelText('Nombre Completo'), { target: { value: 'Carlos Mendoza' } });
    fireEvent.submit(screen.getByRole('button', { name: 'Registrarse' }).closest('form'));

    expect(alerta).toHaveBeenCalledWith('Cuenta creada con éxito para Carlos Mendoza. Ya puedes iniciar sesión.');
    expect(screen.getByRole('heading', { name: 'Iniciar Sesión' })).toBeDefined();
  });
});
