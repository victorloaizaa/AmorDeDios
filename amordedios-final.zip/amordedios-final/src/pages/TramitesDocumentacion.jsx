import React from 'react';

export default function TramitesDocumentacion() {
  return (
    <main>
      <section className="hero">
        <div className="contenedor">
          <div>
            <p className="hero-eyebrow">Asistencia Legal</p>
            <h1>Trámites y Documentación</h1>
            <p>Nos encargamos de toda la gestión administrativa para liberar a la familia de trámites complejos en momentos difíciles.</p>
          </div>
          <div className="hero-imagen">
            <img src="/img/preparativo.jpg" alt="Trámites y Asesoría" />
          </div>
        </div>
      </section>
      <section className="seccion">
        <div className="contenedor">
          <h2>Gestión Integral</h2>
          <ul>
            <li>• Certificados de defunción y Registro Civil.</li>
            <li>• Paz y Salvo e inscripción sanitaria.</li>
            <li>• Tramitación de cuota mortuoria (INP, AFP, IPS, Compañías de Seguro).</li>
          </ul>
        </div>
      </section>
    </main>
  );
}