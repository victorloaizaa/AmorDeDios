import { render, screen, fireEvent } from '@testing-library/react';
import Tienda from './Tienda';
import { PRODUCTOS } from '../data/productos';
import { CLAVE_CARRITO } from '../utils/carrito';

const cantidadDe = (categoria) => PRODUCTOS.filter((p) => p.categoria === categoria).length;

describe('Tienda - filtros y agregar al carrito', () => {
  it('parte mostrando solo los planes', () => {
    render(<Tienda />);
    expect(screen.getAllByRole('button', { name: 'Agregar al Plan' }).length).toBe(cantidadDe('planes'));
  });

  it('al cambiar el filtro se actualiza el estado y la lista de productos', () => {
    render(<Tienda />);

    fireEvent.click(screen.getByRole('button', { name: 'Urnas' }));
    expect(screen.getAllByRole('button', { name: 'Agregar al Plan' }).length).toBe(cantidadDe('urnas'));
    expect(screen.getByRole('button', { name: 'Urnas' }).className).toContain('activo');

    fireEvent.click(screen.getByRole('button', { name: 'Flores' }));
    expect(screen.getAllByRole('button', { name: 'Agregar al Plan' }).length).toBe(cantidadDe('flores'));
  });

  it('agregar guarda el producto en localStorage y muestra el aviso (mocks de localStorage y alert)', () => {
    spyOn(Storage.prototype, 'getItem').and.returnValue(null);
    const setItem = spyOn(Storage.prototype, 'setItem');
    const alerta = spyOn(window, 'alert');
    const primerPlan = PRODUCTOS.find((p) => p.categoria === 'planes');

    render(<Tienda />);
    fireEvent.click(screen.getAllByRole('button', { name: 'Agregar al Plan' })[0]);

    expect(setItem).toHaveBeenCalled();
    const [clave, valor] = setItem.calls.mostRecent().args;
    expect(clave).toBe(CLAVE_CARRITO);
    expect(JSON.parse(valor)[0].id).toBe(primerPlan.id);
    expect(alerta).toHaveBeenCalledWith(`¡"${primerPlan.nombre}" agregado al carrito!`);
  });
});
