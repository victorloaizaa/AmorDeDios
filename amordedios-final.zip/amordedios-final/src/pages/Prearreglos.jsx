import React, { useState } from 'react';
import { Link } from 'react-router-dom';

export default function Prearreglos() {
  const [cuotas, setCuotas] = useState(12);
  const [planSeleccionado, setPlanSeleccionado] = useState(950000); // parte con el plan esencial (primera opción)
  const [faqAbierta, setFaqAbierta] = useState(null);

  const toggleFaq = (index) => {
    setFaqAbierta(faqAbierta === index ? null : index);
  };

  const valorCuotaMensual = Math.round(planSeleccionado / cuotas);

  return (
    <main style={{ paddingBottom: '4rem', background: '#fcfbf7' }}>
      {/* HERO DIFERENCIADO - ESTILO PREMIUM BANCARIO/SEGUROS */}
      <section style={{
        background: 'linear-gradient(135deg, #0b1321 0%, #172a45 100%)',
        color: '#ffffff',
        padding: '4rem 1.5rem',
        borderBottom: '3rem solid #1b263b',
        position: 'relative'
      }}>
        <div className="contenedor" style={{ maxWidth: '1000px', margin: '0 auto', textAlign: 'center' }}>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.5rem',
            background: 'rgba(212, 175, 55, 0.15)',
            border: '1px solid #d4af37',
            padding: '0.4rem 1.2rem',
            borderRadius: '30px',
            color: '#d4af37',
            fontWeight: 'bold',
            fontSize: '0.85rem',
            marginBottom: '1.2rem',
            letterSpacing: '1px'
          }}>
            <span>🛡️</span> PLANIFICACIÓN PREVENTIVA Y PROTECCIÓN FAMILIAR
          </div>
          <h1 style={{ fontSize: '2.8rem', fontFamily: 'serif', color: '#f5f5f5', marginBottom: '1.2rem', lineHeight: '1.2' }}>
            Planifica hoy con serenidad, <br /><span style={{ color: '#d4af37' }}>cuida el mañana de tu familia</span>
          </h1>
          <p style={{ fontSize: '1.1rem', color: '#cbd5e1', maxWidth: '780px', margin: '0 auto 2rem', lineHeight: '1.7' }}>
            Los Prearreglos Funerarios garantizan el cumplimiento de tus decisiones, congelan las tarifas frente a la inflación y evitan imprevistos económicos en momentos vulnerables.
          </p>

          <div style={{ display: 'flex', gap: '1.5rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <a href="#cotizador" style={{
              background: '#d4af37',
              color: '#0b1321',
              padding: '0.9rem 2.2rem',
              borderRadius: '8px',
              fontWeight: 'bold',
              textDecoration: 'none',
              fontSize: '1rem',
              boxShadow: '0 4px 15px rgba(212, 175, 55, 0.3)'
            }}>
              CALCULAR MI PLAN EN CUOTAS
            </a>
            <Link to="/contacto" style={{
              background: 'transparent',
              color: '#ffffff',
              padding: '0.9rem 2.2rem',
              borderRadius: '8px',
              fontWeight: 'bold',
              textDecoration: 'none',
              fontSize: '1rem',
              border: '1px solid rgba(255,255,255,0.4)'
            }}>
              HABLAR CON UN CONSEJERO
            </Link>
          </div>
        </div>
      </section>

      {/* COTIZADOR / CALCULADORA INTERACTIVA DE PREARREGLOS */}
      <section id="cotizador" style={{ marginTop: '-2.5rem', padding: '0 1rem' }}>
        <div className="contenedor" style={{ maxWidth: '900px', margin: '0 auto' }}>
          <div style={{
            background: '#ffffff',
            borderRadius: '16px',
            padding: '2.5rem',
            boxShadow: '0 12px 35px rgba(0,0,0,0.1)',
            border: '2px solid #d4af37'
          }}>
            <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
              <h2 style={{ color: '#1b263b', fontFamily: 'serif', fontSize: '1.8rem', marginBottom: '0.5rem' }}>
                Simulador Rápido de Prearreglo
              </h2>
              <p style={{ color: '#666', fontSize: '0.95rem' }}>
                Estima la cuota mensual de tu contrato preventivo según tus preferencias
              </p>
            </div>

            <div className="row row-cols-1 row-cols-md-2 g-4 align-items-center">
              {/* Opciones del cotizador */}
              <div className="col">
                <div className="h-100">
                  <label htmlFor="plan-prearreglo" style={{ display: 'block', fontWeight: 'bold', color: '#1b263b', marginBottom: '0.5rem', fontSize: '0.95rem' }}>
                    1. Selecciona el Tipo de Plan:
                  </label>
                  <select
                    id="plan-prearreglo"
                    value={planSeleccionado}
                    onChange={(e) => setPlanSeleccionado(Number(e.target.value))}
                    style={{
                      width: '100%',
                      padding: '0.8rem',
                      borderRadius: '8px',
                      border: '1px solid #ccc',
                      marginBottom: '1.5rem',
                      fontSize: '0.95rem',
                      background: '#fcfcfc'
                    }}
                  >
                    <option value={950000}>Plan Esencial Preventivo - $950.000</option>
                    <option value={1450000}>Plan Tradicional Familiar - $1.450.000</option>
                    <option value={2200000}>Plan Senior Honor Preventivo - $2.200.000</option>
                  </select>

                  <label htmlFor="cuotas-prearreglo" style={{ display: 'block', fontWeight: 'bold', color: '#1b263b', marginBottom: '0.5rem', fontSize: '0.95rem' }}>
                    2. Elige el plazo de pago ({cuotas} meses):
                  </label>
                  <input
                    id="cuotas-prearreglo"
                    type="range"
                    min="6" 
                    max="36" 
                    step="6"
                    value={cuotas} 
                    onChange={(e) => setCuotas(Number(e.target.value))}
                    style={{ width: '100%', accentColor: '#d4af37', cursor: 'pointer', marginBottom: '0.5rem' }}
                  />
                  <div style={{ display: 'flex', justifyContent: 'space-between', color: '#777', fontSize: '0.8rem' }}>
                    <span>6 meses</span>
                    <span>12 meses</span>
                    <span>24 meses</span>
                    <span>36 meses</span>
                  </div>
                </div>
              </div>

              {/* Resultado del cálculo */}
              <div className="col">
                <div className="h-100" style={{
                  background: '#0b1321',
                  padding: '2rem',
                  borderRadius: '12px',
                  textAlign: 'center',
                  color: '#ffffff',
                  border: '1px solid #d4af37'
                }}>
                  <span style={{ color: '#d4af37', textTransform: 'uppercase', fontSize: '0.8rem', letterSpacing: '1px', fontWeight: 'bold' }}>
                    Estimación Cuota Mensual
                  </span>
                  <div style={{ fontSize: '2.5rem', color: '#ffffff', fontWeight: 'bold', margin: '0.8rem 0', fontFamily: 'serif' }}>
                    <span data-testid="cuota-mensual">${valorCuotaMensual.toLocaleString('es-CL')}</span> <span style={{ fontSize: '1rem', color: '#d4af37' }}>/ mes</span>
                  </div>
                  <p style={{ fontSize: '0.85rem', color: '#aaa', marginBottom: '1.5rem' }}>
                    Precio congelado en UF/CLP al momento de la firma. Sin cobros sorpresas.
                  </p>
                  <Link to="/contacto" style={{
                    display: 'block',
                    background: '#d4af37',
                    color: '#0b1321',
                    padding: '0.75rem',
                    borderRadius: '6px',
                    fontWeight: 'bold',
                    textDecoration: 'none',
                    fontSize: '0.9rem'
                  }}>
                    SOLICITAR CONTRATO OFICIAL
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PROCESO PASO A PASO (LÍNEA DE TIEMPO HORIZONTAL) */}
      <section style={{ padding: '4rem 1.5rem 2rem' }}>
        <div className="contenedor" style={{ maxWidth: '1000px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
            <h2 style={{ fontSize: '2rem', color: '#1b263b', fontFamily: 'serif' }}>
              ¿Cómo funciona un Prearreglo Funerario?
            </h2>
            <p style={{ color: '#666', fontSize: '1rem' }}>3 pasos simples para asegurar la tranquilidad de tu hogar</p>
          </div>

          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            {/* Paso 1 */}
            <div className="col">
              <div className="h-100" style={{ background: '#ffffff', padding: '2rem', borderRadius: '12px', boxShadow: '0 4px 15px rgba(0,0,0,0.04)', borderTop: '4px solid #d4af37' }}>
                <div style={{ background: '#fdf8e7', color: '#b38f28', width: '45px', height: '45px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', fontSize: '1.2rem', marginBottom: '1rem' }}>1</div>
                <h3 style={{ color: '#1b263b', fontSize: '1.2rem', fontFamily: 'serif', marginBottom: '0.8rem' }}>Diseño a la Medida</h3>
                <p style={{ color: '#555', fontSize: '0.92rem', lineHeight: '1.6' }}>
                  Eliges el tipo de sepultura o cremación, la urna, la capilla de velatorio y los detalles rituales o musicales de tu preferencia.
                </p>
              </div>
            </div>

            {/* Paso 2 */}
            <div className="col">
              <div className="h-100" style={{ background: '#ffffff', padding: '2rem', borderRadius: '12px', boxShadow: '0 4px 15px rgba(0,0,0,0.04)', borderTop: '4px solid #1b263b' }}>
                <div style={{ background: '#1b263b', color: '#ffffff', width: '45px', height: '45px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', fontSize: '1.2rem', marginBottom: '1rem' }}>2</div>
                <h3 style={{ color: '#1b263b', fontSize: '1.2rem', fontFamily: 'serif', marginBottom: '0.8rem' }}>Congelamiento de Precio</h3>
                <p style={{ color: '#555', fontSize: '0.92rem', lineHeight: '1.6' }}>
                  Firmas el contrato garantizando que el valor total acordado no sufrirá alzas futuras por inflación o emergencias sanitarias.
                </p>
              </div>
            </div>

            {/* Paso 3 */}
            <div className="col">
              <div className="h-100" style={{ background: '#ffffff', padding: '2rem', borderRadius: '12px', boxShadow: '0 4px 15px rgba(0,0,0,0.04)', borderTop: '4px solid #d4af37' }}>
                <div style={{ background: '#fdf8e7', color: '#b38f28', width: '45px', height: '45px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', fontSize: '1.2rem', marginBottom: '1rem' }}>3</div>
                <h3 style={{ color: '#1b263b', fontSize: '1.2rem', fontFamily: 'serif', marginBottom: '0.8rem' }}>Resguardo Inmediato</h3>
                <p style={{ color: '#555', fontSize: '0.92rem', lineHeight: '1.6' }}>
                  Recibes tu certificado y póliza transferible. En el momento que se requiera, tu familia solo activará el servicio con una llamada 24/7.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ACORDEÓN DE PREGUNTAS FRECUENTES (FAQ) */}
      <section style={{ padding: '2rem 1.5rem 4rem' }}>
        <div className="contenedor" style={{ maxWidth: '850px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
            <h2 style={{ fontSize: '1.8rem', color: '#1b263b', fontFamily: 'serif' }}>
              Preguntas Frecuentes sobre Prearreglos
            </h2>
            <p style={{ color: '#666', fontSize: '0.95rem' }}>Resolvemos tus dudas antes de tomar una decisión</p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {[
              {
                q: "¿Qué ocurre si fallezco antes de terminar de pagar las cuotas del plan?",
                a: "Contamos con pólizas de saldo insólito o protección de cuotas. Según el plan contratado, el servicio queda cubierto al 100% para tu familia sin exigir saldos adeudados."
              },
              {
                q: "¿Puedo transferir el prearreglo a otra persona en caso de necesidad urgente?",
                a: "Sí, todos nuestros contratos de necesidad futura son 100% transferibles a familiares directos o terceros sin penalización administrativa."
              },
              {
                q: "¿Qué respaldo legal tienen estos contratos?",
                a: "Todos los contratos son extendidos bajo normativa civil chilena vigente, respaldados con boleta/factura y certificado de vigencia expedido por Funeraria Amor de Dios."
              },
              {
                q: "¿Se puede complementar con la Cuota Mortuoria de AFP/IPS?",
                a: "Totalmente. Al momento de la activación, gestionamos la asignación por muerte o cuota mortuoria para reembolsar o abonar directamente al contrato."
              }
            ].map((faq, idx) => (
              <div 
                key={idx}
                onClick={() => toggleFaq(idx)}
                style={{
                  background: '#ffffff',
                  borderRadius: '8px',
                  border: '1px solid #e2d192',
                  padding: '1.2rem 1.5rem',
                  cursor: 'pointer',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.02)'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontWeight: 'bold', color: '#1b263b' }}>
                  <span>{faq.q}</span>
                  <span style={{ color: '#d4af37', fontSize: '1.2rem' }}>{faqAbierta === idx ? '−' : '+'}</span>
                </div>
                {faqAbierta === idx && (
                  <p style={{ marginTop: '0.8rem', color: '#555', fontSize: '0.93rem', lineHeight: '1.6', paddingTop: '0.8rem', borderTop: '1px solid #f0f0f0' }}>
                    {faq.a}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BANNER INFORMATIVO FINAL */}
      <section className="contenedor" style={{ maxWidth: '1000px', margin: '0 auto' }}>
        <div style={{
          background: 'linear-gradient(135deg, #0b1321 0%, #1b263b 100%)',
          borderRadius: '16px',
          padding: '2.5rem',
          textAlign: 'center',
          color: '#ffffff',
          boxShadow: '0 8px 25px rgba(0,0,0,0.15)',
          border: '1px solid #d4af37'
        }}>
          <h2 style={{ fontSize: '1.8rem', color: '#d4af37', fontFamily: 'serif', marginBottom: '1rem' }}>
            Protege hoy la tranquilidad de quienes más amas
          </h2>
          <p style={{ maxWidth: '650px', margin: '0 auto 1.8rem', color: '#e0e0e0', fontSize: '1rem', lineHeight: '1.6' }}>
            Nuestros consejeros en prevención familiar están disponibles para asesorarte en nuestras oficinas o en la comodidad de tu hogar de forma estrictamente confidencial.
          </p>
          <Link to="/contacto" className="boton" style={{ padding: '0.85rem 2rem', fontSize: '0.95rem' }}>
            SOLICITAR ASESORÍA PRIVADA
          </Link>
        </div>
      </section>
    </main>
  );
}