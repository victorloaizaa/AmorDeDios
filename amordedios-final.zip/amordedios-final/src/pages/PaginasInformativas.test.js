import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Nosotros from './Nosotros';
import VelatorioCapilla from './VelatorioCapilla';
import Cremacion from './Cremacion';
import Traslados from './Traslados';
import TramitesDocumentacion from './TramitesDocumentacion';
import Floristeria from './Floristeria';
import AcompanamientoEspiritual from './AcompanamientoEspiritual';
import ContencionEmocional from './ContencionEmocional';
import ConveniosSeguros from './ConveniosSeguros';

// páginas que son solo de contenido: revisamos que todas carguen con su título principal
const paginas = {
  Nosotros,
  VelatorioCapilla,
  Cremacion,
  Traslados,
  TramitesDocumentacion,
  Floristeria,
  AcompanamientoEspiritual,
  ContencionEmocional,
  ConveniosSeguros,
};

describe('Páginas informativas - renderizado', () => {
  Object.entries(paginas).forEach(([nombre, Pagina]) => {
    it(`${nombre} se muestra con un título h1`, () => {
      render(
        <MemoryRouter>
          <Pagina />
        </MemoryRouter>
      );
      expect(screen.getAllByRole('heading', { level: 1 }).length).toBe(1);
    });
  });
});
