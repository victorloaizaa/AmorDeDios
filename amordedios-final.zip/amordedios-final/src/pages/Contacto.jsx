import React, { useState } from 'react';
import { validarNombre, validarCorreo, validarTelefono, validarPlan } from '../utils/validaciones';

// qué función valida cada campo (el mensaje no se valida, es opcional)
const VALIDADORES = {
  nombre: validarNombre,
  correo: validarCorreo,
  telefono: validarTelefono,
  plan: validarPlan,
};

const FORM_VACIO = { nombre: '', correo: '', telefono: '', plan: '', mensaje: '' };
const SIN_ERRORES = { nombre: '', correo: '', telefono: '', plan: '' };
const SIN_VALIDAR = { nombre: false, correo: false, telefono: false, plan: false };

export default function Contacto() {
  const [formData, setFormData] = useState(FORM_VACIO);
  const [errores, setErrores] = useState(SIN_ERRORES);
  const [validados, setValidados] = useState(SIN_VALIDAR);
  const [confirmado, setConfirmado] = useState(false);

  // valida un campo, guarda el error en el estado y devuelve true si está ok
  const validarCampo = (campo, valor = formData[campo]) => {
    const error = VALIDADORES[campo](valor);
    setErrores((prev) => ({ ...prev, [campo]: error }));
    setValidados((prev) => ({ ...prev, [campo]: error === '' }));
    return error === '';
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    // el plan se valida apenas se elige; los otros campos, si ya tenían error,
    // se revalidan mientras se escribe para que el mensaje se vaya al corregir
    if (name === 'plan' || (errores[name] && VALIDADORES[name])) {
      validarCampo(name, value);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // se validan todos para marcar todos los errores de una vez
    const resultados = Object.keys(VALIDADORES).map((campo) => validarCampo(campo));

    if (resultados.every(Boolean)) {
      setConfirmado(true);
      setFormData(FORM_VACIO);
      setValidados(SIN_VALIDAR);
    } else {
      setConfirmado(false);
    }
  };

  // is-invalid (rojo) muestra el mensaje de .invalid-feedback, is-valid lo deja en verde
  const claseValidacion = (campo) => {
    if (errores[campo]) return 'is-invalid';
    if (validados[campo]) return 'is-valid';
    return '';
  };

  return (
    <main>
      <section className="hero">
        <div className="contenedor">
          <div>
            <p className="hero-eyebrow">Contacto</p>
            <h1>Atención las 24 horas</h1>
            <p>
              Estamos disponibles en todo momento para orientarte con respeto y transparencia. Escríbenos o visita cualquiera de nuestras sucursales.
            </p>
          </div>
          <div className="hero-imagen">
            <img src="/img/foto se un servicio.jpeg" alt="Atención al cliente Funeraria Amor de Dios" />
          </div>
        </div>
      </section>

      <section className="seccion">
        <div className="contenedor">
          <div className="seccion-titulo">
            <h2>Formulario de Consulta</h2>
          </div>

          <form id="formulario-contacto" className="formulario-contacto card border-0 shadow-sm p-3 p-md-4" onSubmit={handleSubmit} noValidate>
            {/* en celular un campo por fila, desde tablet dos */}
            <div className="row g-3">
              {/* Campo Nombre */}
              <div className="col-12 col-md-6">
                <label htmlFor="nombre" className="form-label">Nombre Completo *</label>
                <input
                  type="text"
                  id="nombre"
                  name="nombre"
                  autoComplete="name"
                  className={`form-control ${claseValidacion('nombre')}`}
                  value={formData.nombre}
                  onChange={handleChange}
                  onBlur={() => validarCampo('nombre')}
                  placeholder="Ej. María González"
                  aria-describedby="error-nombre"
                />
                <div id="error-nombre" className="invalid-feedback" role="alert">{errores.nombre}</div>
              </div>

              {/* Campo Correo */}
              <div className="col-12 col-md-6">
                <label htmlFor="correo" className="form-label">Correo Electrónico *</label>
                <input
                  type="email"
                  id="correo"
                  name="correo"
                  autoComplete="email"
                  className={`form-control ${claseValidacion('correo')}`}
                  value={formData.correo}
                  onChange={handleChange}
                  onBlur={() => validarCampo('correo')}
                  placeholder="Ej. maria.gonzalez@correo.cl"
                  aria-describedby="error-correo"
                />
                <div id="error-correo" className="invalid-feedback" role="alert">{errores.correo}</div>
              </div>

              {/* Campo Teléfono */}
              <div className="col-12 col-md-6">
                <label htmlFor="telefono" className="form-label">Teléfono de Contacto *</label>
                <input
                  type="tel"
                  id="telefono"
                  name="telefono"
                  autoComplete="tel"
                  className={`form-control ${claseValidacion('telefono')}`}
                  value={formData.telefono}
                  onChange={handleChange}
                  onBlur={() => validarCampo('telefono')}
                  placeholder="Ej. +56 9 1234 5678"
                  aria-describedby="error-telefono"
                />
                <div id="error-telefono" className="invalid-feedback" role="alert">{errores.telefono}</div>
              </div>

              {/* Selector de Plan */}
              <div className="col-12 col-md-6">
                <label htmlFor="plan" className="form-label">Plan o Servicio de Interés *</label>
                <select
                  id="plan"
                  name="plan"
                  className={`form-select ${claseValidacion('plan')}`}
                  value={formData.plan}
                  onChange={handleChange}
                  aria-describedby="error-plan"
                >
                  <option value="">-- Selecciona una opción --</option>
                  <option value="basico">Plan Básico Tradicional</option>
                  <option value="intermedio">Plan Familiar Superior</option>
                  <option value="premium">Plan Honor Imperial</option>
                  <option value="cremacion">Plan Integral de Cremación</option>
                  <option value="otro">Consulta General / Otro Servicio</option>
                </select>
                <div id="error-plan" className="invalid-feedback" role="alert">{errores.plan}</div>
              </div>

              {/* Campo Mensaje */}
              <div className="col-12">
                <div className="d-flex justify-content-between">
                  <label htmlFor="mensaje" className="form-label">Mensaje o Detalles Adicionales</label>
                  <small className="text-muted">
                    <span id="contador-mensaje">{formData.mensaje.length}</span> caracteres
                  </small>
                </div>
                <textarea
                  id="mensaje"
                  name="mensaje"
                  rows="4"
                  className="form-control"
                  value={formData.mensaje}
                  onChange={handleChange}
                  placeholder="Escribe aquí cualquier duda, indicación sobre la comuna o requerimiento especial..."
                ></textarea>
              </div>

              <div className="col-12 col-md-auto">
                <button type="submit" className="btn btn-dark btn-lg w-100">
                  Enviar Mensaje
                </button>
              </div>

              {/* Confirmación */}
              {confirmado && (
                <div className="col-12">
                  <div id="confirmacion" className="alert alert-success mb-0" role="status">
                    ¡Gracias por tu mensaje! Un asesor de Amor de Dios se pondrá en contacto contigo a la brevedad.
                  </div>
                </div>
              )}
            </div>
          </form>
        </div>
      </section>
    </main>
  );
}