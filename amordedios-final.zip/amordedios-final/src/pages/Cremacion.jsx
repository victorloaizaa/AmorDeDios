import React from 'react';

export default function Cremacion() {
  return (
    <main>
      <section className="hero">
        <div className="contenedor">
          <div>
            <p className="hero-eyebrow">Servicios</p>
            <h1>Servicios de Cremación</h1>
            <p>
              Proceso integral certificado con acompañamiento ceremonial respetuoso y transparente en cada etapa.
            </p>
          </div>
          <div className="hero-imagen">
            <img src="/img/cremacion.jpg" alt="Servicio de Cremación" />
          </div>
        </div>
      </section>

      <section className="seccion">
        <div className="contenedor">
          <div className="seccion-titulo">
            <h2>Cobertura del Plan de Cremación</h2>
          </div>
          <ul style={{ lineHeight: '1.8', fontSize: '1.05rem' }}>
            <li>• Gestión legal y permisos ante Autoridades Sanitarias.</li>
            <li>• Urna especial para el proceso de cinerario.</li>
            <li>• Ceremonia de despedida previa antes de la cremación.</li>
            <li>• Selección de ánfora cineraria de nuestra colección.</li>
            <li>• Traslado certificado al cinerario correspondiente.</li>
          </ul>
        </div>
      </section>
    </main>
  );
}