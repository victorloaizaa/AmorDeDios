import { Link } from 'react-router-dom';

export default function Nosotros() {
  return (
    <main>
      <section className="hero">
        <div className="contenedor">
          <div>
            <p className="hero-eyebrow">Nuestra historia</p>
            <h1>27 años acompañando a familias en Chile</h1>
            <p>Funeraria Amor de Dios nació en 2010 en Providencia. Hoy contamos con sucursales en la Región Metropolitana, manteniendo la misma cercanía de siempre.</p>
          </div>
          <div className="hero-imagen">
            <img src="/img/velacion.jpg" alt="Manos entrelazadas en un gesto de apoyo y consuelo" />
          </div>
        </div>
      </section>

      <section className="seccion">
        <div className="contenedor">
          <div className="seccion-titulo"><h2>Nuestra misión</h2></div>
          <article>
            <p>Acompañar a cada familia con respeto, calidez y profesionalismo durante uno de los momentos más difíciles de la vida, encargándonos de cada detalle con dedicación y empatía.</p>
          </article>
        </div>
      </section>

      <section className="seccion">
        <div className="contenedor">
          <div className="seccion-titulo"><h2>Nuestros valores</h2></div>
          <div className="grid-servicios">
            <article className="servicio">
              <h3>Cercanía</h3>
              <p>Escuchamos a cada familia y adaptamos el servicio a sus creencias y posibilidades.</p>
            </article>
            <article className="servicio">
              <h3>Transparencia</h3>
              <p>Presupuestos claros, explicados paso a paso antes de confirmar cualquier servicio.</p>
            </article>
            <article className="servicio">
              <h3>Disponibilidad</h3>
              <p>Atención las 24 horas, los 365 días del año, en todas nuestras sucursales.</p>
            </article>
          </div>
        </div>
      </section>

      <section className="cta-contacto">
        <div className="contenedor" style={{ textAlign: 'center', padding: '40px 20px' }}>
          <h2>¿Quieres conocer más sobre nuestros servicios?</h2>
          <p style={{ marginBottom: '25px' }}>Estamos disponibles para orientarte sin compromiso.</p>
          <Link to="/contacto" className="boton" style={{ display: 'inline-block', marginTop: '15px' }}>Contáctanos</Link>
        </div>
      </section>
    </main>
  );
}