import React from 'react';
import { Link } from 'react-router-dom';

export default function Floristeria() {
  return (
    <main>
      <section className="hero">
        <div className="contenedor">
          <div>
            <p className="hero-eyebrow">Arreglos Florales</p>
            <h1>Floristería Funeral</h1>
            <p>Diseños florales ceremoniales con flores naturales seleccionadas de alta frescura.</p>
          </div>
          <div className="hero-imagen">
            <img src="/img/arreglosflorales.jpg" alt="Floristería Funeral" />
          </div>
        </div>
      </section>
      <section className="seccion">
        <div className="contenedor" style={{ textAlign: 'center' }}>
          <h2>Catálogo de Flores Disponibles</h2>
          <p style={{ marginBottom: '1.5rem' }}>Puedes elegir coronas ceremoniales, mantos cubre urnas o arreglos de pie en nuestra sección dedicada.</p>
          <Link to="/tienda" className="boton">Ver Opciones de Flores</Link>
        </div>
      </section>
    </main>
  );
}