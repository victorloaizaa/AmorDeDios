import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Carrito from './Carrito';

// carrito simulado que devolvemos en vez del localStorage real
const carritoGuardado = [
  { id: 'corona', nombre: 'Corona Ceremonial', categoria: 'FLORES', precio: 75000, cantidad: 2, imagen: '/img/a.jpg' },
  { id: 'urna', nombre: 'Urna Huasco', categoria: 'URNAS', precio: 950000, cantidad: 1, imagen: '/img/b.jpg' },
];

const renderCarrito = () =>
  render(
    <MemoryRouter>
      <Carrito />
    </MemoryRouter>
  );

describe('Carrito - estado y localStorage simulado', () => {
  let setItem;

  beforeEach(() => {
    spyOn(Storage.prototype, 'getItem').and.returnValue(JSON.stringify(carritoGuardado));
    setItem = spyOn(Storage.prototype, 'setItem');
  });

  it('carga los productos guardados y calcula el total', () => {
    renderCarrito();

    expect(screen.getByText('Corona Ceremonial')).toBeDefined();
    expect(screen.getByText('Urna Huasco')).toBeDefined();
    // 75.000 x 2 + 950.000 = 1.100.000
    expect(screen.getByTestId('total').textContent).toContain('1.100.000');
  });

  it('al sumar una unidad se recalcula el total y se guarda', () => {
    renderCarrito();

    fireEvent.click(screen.getAllByRole('button', { name: 'Sumar uno' })[0]);

    expect(screen.getByTestId('total').textContent).toContain('1.175.000');
    expect(setItem).toHaveBeenCalled();
  });

  it('al quitar un producto desaparece de la lista', () => {
    renderCarrito();

    fireEvent.click(screen.getByRole('button', { name: 'Quitar Urna Huasco' }));

    expect(screen.queryByText('Urna Huasco')).toBeNull();
    expect(screen.getByTestId('total').textContent).toContain('150.000');
  });

  it('vaciar carrito muestra el mensaje de carrito vacío', () => {
    renderCarrito();

    fireEvent.click(screen.getByRole('button', { name: 'Vaciar Carrito' }));

    expect(screen.getByText('Tu carrito está vacío')).toBeDefined();
    expect(setItem).toHaveBeenCalledWith('carrito_amor_de_dios', '[]');
  });

  it('confirmar reserva avisa con un alert y deja el carrito vacío', () => {
    const alerta = spyOn(window, 'alert');
    renderCarrito();

    fireEvent.click(screen.getByRole('button', { name: 'CONFIRMAR RESERVA' }));

    expect(alerta).toHaveBeenCalled();
    expect(screen.getByText('Tu carrito está vacío')).toBeDefined();
  });
});
