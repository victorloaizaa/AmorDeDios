import { render, screen, fireEvent, act } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Home from './Home';

const renderHome = () =>
  render(
    <MemoryRouter>
      <Home />
    </MemoryRouter>
  );

describe('Home - carrusel', () => {
  // jasmine.clock() simula el reloj, así no hay que esperar 5,5 segundos de verdad
  beforeEach(() => jasmine.clock().install());
  afterEach(() => jasmine.clock().uninstall());

  it('parte en la primera diapositiva', () => {
    renderHome();
    expect(screen.getByText('PLANES A TU MEDIDA')).toBeDefined();
  });

  it('avanza solo cada 5,5 segundos (reloj simulado)', () => {
    renderHome();

    act(() => jasmine.clock().tick(5500));

    expect(screen.getByText('ATENCIÓN LAS 24 HORAS')).toBeDefined();
  });

  it('los botones siguiente y anterior cambian la diapositiva', () => {
    renderHome();

    fireEvent.click(screen.getByRole('button', { name: 'Diapositiva siguiente' }));
    expect(screen.getByText('ATENCIÓN LAS 24 HORAS')).toBeDefined();

    fireEvent.click(screen.getByRole('button', { name: 'Diapositiva anterior' }));
    expect(screen.getByText('PLANES A TU MEDIDA')).toBeDefined();
  });

  it('desde la primera, "anterior" vuelve a la última y los puntos permiten saltar', () => {
    renderHome();

    fireEvent.click(screen.getByRole('button', { name: 'Diapositiva anterior' }));
    expect(screen.queryByText('PLANES A TU MEDIDA')).toBeNull();

    fireEvent.click(screen.getByRole('button', { name: 'Ir a la diapositiva 3' }));
    expect(screen.getByText('CREMACIÓN Y CAPILLAS')).toBeDefined();
  });
});
