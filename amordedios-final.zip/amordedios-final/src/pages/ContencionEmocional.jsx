import React from 'react';
import { Link } from 'react-router-dom';

export default function ContencionEmocional() {
  return (
    <main style={{ paddingBottom: '3rem' }}>
      <section className="hero">
        <div className="contenedor" style={{ textAlign: 'center' }}>
          <span style={{
            background: '#fdf8e7',
            color: '#b38f28',
            padding: '0.4rem 1.2rem',
            borderRadius: '20px',
            fontSize: '0.85rem',
            fontWeight: 'bold',
            letterSpacing: '1px',
            display: 'inline-block',
            marginBottom: '0.8rem',
            border: '1px solid #e2d192'
          }}>
            APOYO PSICOLÓGICO Y DUELO
          </span>
          <h1 style={{ fontSize: '2.5rem', color: '#1b263b', marginBottom: '1rem', fontFamily: 'serif' }}>
            Contención Emocional y Apoyo al Duelo
          </h1>
          <p style={{ maxWidth: '750px', margin: '0 auto', color: '#555', fontSize: '1.05rem', lineHeight: '1.6' }}>
            Te acompañamos con la calidez, respeto y profesionalismo que tú y tu familia necesitan para transitar el proceso de pérdida.
          </p>
        </div>
      </section>

      <section style={{ marginTop: '2.5rem' }}>
        <div className="contenedor">
          <div className="row row-cols-1 row-cols-md-2 g-4 align-items-center mb-5">
            {/* Ilustración de Contención Emocional */}
            <div className="col">
              <div className="h-100" style={{ borderRadius: '16px', overflow: 'hidden', boxShadow: '0 8px 25px rgba(0,0,0,0.08)', background: '#fdfbf7', padding: '1rem', border: '1px solid #e2d192', textAlign: 'center' }}>
                <svg viewBox="0 0 500 350" style={{ width: '100%', height: 'auto', maxHeight: '380px', display: 'block' }}>
                  <rect width="500" height="350" rx="12" fill="#f4f7f6"/>
                  <circle cx="250" cy="150" r="90" fill="#e0ece8" opacity="0.7"/>
                  {/* Ícono de abrazo / corazón simétrico */}
                  <path d="M 250,210 C 200,160 170,120 200,90 C 220,70 245,85 250,105 C 255,85 280,70 300,90 C 330,120 300,160 250,210 Z" fill="#d4af37"/>
                  <path d="M 190,200 Q 250,150 310,200 Q 280,240 250,230 Q 220,240 190,200 Z" fill="#1b263b" opacity="0.8"/>
                  <text x="250" y="295" textAnchor="middle" fill="#1b263b" fontSize="18" fontFamily="serif" fontWeight="bold">Orientación y CalidezHumana</text>
                  <text x="250" y="318" textAnchor="middle" fill="#666" fontSize="13">Acompañamiento Profesional en el Duelo</text>
                </svg>
              </div>
            </div>

            <div className="col">
              <div className="h-100">
                <h2 style={{ fontSize: '1.8rem', color: '#1b263b', fontFamily: 'serif', marginBottom: '1rem' }}>
                  Un Hombro Amigo en los Momentos Más Difíciles
                </h2>
                <p style={{ color: '#444', lineHeight: '1.7', marginBottom: '1.2rem', fontSize: '0.98rem' }}>
                  El duelo es un proceso único e individual. En Funeraria Amor de Dios disponemos de profesionales capacitados en contención emocional para brindar un espacio de escucha activa, contención y consuelo durante y después de los servicios exequiales.
                </p>
                <p style={{ color: '#444', lineHeight: '1.7', marginBottom: '1.5rem', fontSize: '0.98rem' }}>
                  Nuestra misión es aliviar la carga emocional que implica la pérdida de un ser querido, orientando a la familia con empatía y absoluto respeto hacia sus tiempos y sentimientos.
                </p>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '1.2rem' }}>✓</span>
                    <span style={{ color: '#333', fontSize: '0.95rem' }}>Primera atención y contención en momentos de crisis</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '1.2rem' }}>✓</span>
                    <span style={{ color: '#333', fontSize: '0.95rem' }}>Guías y material de apoyo para el manejo del duelo familiar</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '1.2rem' }}>✓</span>
                    <span style={{ color: '#333', fontSize: '0.95rem' }}>Atención orientada a niños, adultos y adultos mayores</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* TARJETAS */}
          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 mb-5">
            <div className="col">
              <div className="h-100" style={{ background: '#fff', padding: '1.8rem', borderRadius: '12px', border: '1px solid #e8e2ce', boxShadow: '0 4px 15px rgba(0,0,0,0.04)' }}>
                <h3 style={{ color: '#1b263b', fontFamily: 'serif', fontSize: '1.25rem', marginBottom: '0.8rem' }}>Atención Presencial</h3>
                <p style={{ color: '#666', fontSize: '0.92rem', lineHeight: '1.6' }}>Personal especializado presente durante el velatorio para asistir a familiares y seres cercanos.</p>
              </div>
            </div>
            <div className="col">
              <div className="h-100" style={{ background: '#fff', padding: '1.8rem', borderRadius: '12px', border: '1px solid #e8e2ce', boxShadow: '0 4px 15px rgba(0,0,0,0.04)' }}>
                <h3 style={{ color: '#1b263b', fontFamily: 'serif', fontSize: '1.25rem', marginBottom: '0.8rem' }}>Charlas de Orientación</h3>
                <p style={{ color: '#666', fontSize: '0.92rem', lineHeight: '1.6' }}>Encuentros y talleres para abordar las etapas del duelo de forma saludable y comprensiva.</p>
              </div>
            </div>
            <div className="col">
              <div className="h-100" style={{ background: '#fff', padding: '1.8rem', borderRadius: '12px', border: '1px solid #e8e2ce', boxShadow: '0 4px 15px rgba(0,0,0,0.04)' }}>
                <h3 style={{ color: '#1b263b', fontFamily: 'serif', fontSize: '1.25rem', marginBottom: '0.8rem' }}>Asesoría Telefónica</h3>
                <p style={{ color: '#666', fontSize: '0.92rem', lineHeight: '1.6' }}>Línea de soporte disponible para quienes requieran apoyo o contención oportuna.</p>
              </div>
            </div>
          </div>

          {/* BANNER CONTACTO */}
          <div style={{ background: 'linear-gradient(135deg, #0b1321 0%, #1b263b 100%)', borderRadius: '16px', padding: '2.5rem', textAlign: 'center', color: '#ffffff', boxShadow: '0 8px 25px rgba(0,0,0,0.15)', border: '1px solid #d4af37' }}>
            <h2 style={{ fontSize: '1.8rem', color: '#d4af37', fontFamily: 'serif', marginBottom: '1rem' }}>Estamos contigo en todo momento</h2>
            <p style={{ maxWidth: '650px', margin: '0 auto 1.8rem', color: '#e0e0e0', fontSize: '1rem', lineHeight: '1.6' }}>Si necesitas conversar con uno de nuestros asesores o solicitar orientación sobre este servicio, contáctanos hoy mismo.</p>
            <Link to="/contacto" className="boton" style={{ padding: '0.85rem 2rem', fontSize: '0.95rem' }}>CONTACTAR AHORA</Link>
          </div>
        </div>
      </section>
    </main>
  );
}