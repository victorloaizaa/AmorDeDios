import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Prearreglos from './Prearreglos';

const renderPagina = () =>
  render(
    <MemoryRouter>
      <Prearreglos />
    </MemoryRouter>
  );

const cuota = () => screen.getByTestId('cuota-mensual').textContent;

describe('Prearreglos - simulador de cuotas', () => {
  it('parte con el plan esencial en 12 cuotas', () => {
    renderPagina();
    // 950.000 / 12 = 79.167 aprox
    expect(cuota()).toBe('$' + Math.round(950000 / 12).toLocaleString('es-CL'));
  });

  it('recalcula la cuota al cambiar el plan y el plazo', () => {
    renderPagina();

    fireEvent.change(screen.getByLabelText(/Selecciona el Tipo de Plan/), { target: { value: '2200000' } });
    fireEvent.change(screen.getByLabelText(/Elige el plazo de pago/), { target: { value: '24' } });

    expect(cuota()).toBe('$' + Math.round(2200000 / 24).toLocaleString('es-CL'));
    expect(screen.getByText(/Elige el plazo de pago \(24 meses\)/)).toBeDefined();
  });

  it('las preguntas frecuentes se abren y cierran al hacer clic', () => {
    renderPagina();
    const pregunta = screen.getByText(/Cuota Mortuoria/);

    fireEvent.click(pregunta);
    expect(screen.getByText(/asignación por muerte/)).toBeDefined();

    fireEvent.click(pregunta);
    expect(screen.queryByText(/asignación por muerte/)).toBeNull();
  });
});
