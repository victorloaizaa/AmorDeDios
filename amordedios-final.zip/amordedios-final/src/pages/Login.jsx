import React, { useState } from 'react';

export default function Login() {
  const [isRegister, setIsRegister] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    nombre: '',
    telefono: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isRegister) {
      alert(`Cuenta creada con éxito para ${formData.nombre}. Ya puedes iniciar sesión.`);
      setIsRegister(false);
    } else {
      alert(`Bienvenido de nuevo, ${formData.email}`);
    }
  };

  return (
    <main>
      <section className="hero">
        <div className="contenedor text-center mb-3">
          <span className="hero-eslogan-destacado">Portal de Clientes</span>
          <h1 className="hero-titulo-principal">
            {isRegister ? 'Crear una Cuenta' : 'Iniciar Sesión'}
          </h1>
          <p className="text-muted mx-auto mt-2 texto-login">
            Accede para gestionar tus cotizaciones, revisar el estado de tus planes reservados o solicitar asistencia personalizada.
          </p>
        </div>
      </section>

      <section className="seccion">
        {/* columna centrada, más angosta en pantallas grandes */}
        <div className="row justify-content-center mx-0">
          <div className="col-12 col-md-8 col-lg-5">
          <div className="card shadow-sm border-warning-subtle p-3 p-md-4">
            <form onSubmit={handleSubmit}>
              {isRegister && (
                <>
                  <div className="mb-3">
                    <label htmlFor="login-nombre" className="form-label fw-bold">Nombre Completo</label>
                    <input
                      type="text"
                      name="nombre"
                      id="login-nombre"
                      value={formData.nombre}
                      onChange={handleChange}
                      required
                      placeholder="Ej. Carlos Mendoza"
                  className="form-control"
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="login-telefono" className="form-label fw-bold">Teléfono de Contacto</label>
                    <input
                      type="tel"
                      name="telefono"
                      id="login-telefono"
                      value={formData.telefono}
                      onChange={handleChange}
                      required
                      placeholder="+56 9 1234 5678"
                  className="form-control"
                    />
                  </div>
                </>
              )}

              <div className="mb-3">
                <label htmlFor="login-email" className="form-label fw-bold">Correo Electrónico</label>
                <input
                  type="email"
                  name="email"
                      id="login-email"
                  autoComplete="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  placeholder="ejemplo@correo.cl"
                  className="form-control"
                />
              </div>

              <div className="mb-3">
                <label htmlFor="login-password" className="form-label fw-bold">Contraseña</label>
                <input
                  type="password"
                  name="password"
                      id="login-password"
                  autoComplete={isRegister ? "new-password" : "current-password"}
                  value={formData.password}
                  onChange={handleChange}
                  required
                  placeholder="••••••••"
                  className="form-control"
                />
              </div>

              <button
                type="submit"
                className="btn btn-warning btn-lg w-100 fw-bold text-white boton-login"
              >
                {isRegister ? 'Registrarse' : 'Ingresar'}
              </button>
            </form>

            <div className="text-center mt-4">
              {isRegister ? (
                <p>
                  ¿Ya tienes una cuenta?{' '}
                  <button
                    type="button"
                    className="btn btn-link p-0 fw-bold text-warning align-baseline"
                    onClick={() => setIsRegister(false)}
                  >
                    Inicia Sesión aquí
                  </button>
                </p>
              ) : (
                <p>
                  ¿No tienes una cuenta aún?{' '}
                  <button
                    type="button"
                    className="btn btn-link p-0 fw-bold text-warning align-baseline"
                    onClick={() => setIsRegister(true)}
                  >
                    Regístrate aquí
                  </button>
                </p>
              )}
            </div>
          </div>
          </div>
        </div>
      </section>
    </main>
  );
}