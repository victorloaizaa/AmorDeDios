import React, { useState } from 'react';
import ProductoCard from '../components/ProductoCard';
import FiltroCategorias from '../components/FiltroCategorias';
import { PRODUCTOS } from '../data/productos';
import { leerCarrito, guardarCarrito, agregarProducto } from '../utils/carrito';

const CATEGORIAS = [
  { id: 'planes', texto: 'Planes' },
  { id: 'urnas', texto: 'Urnas' },
  { id: 'flores', texto: 'Flores' },
];

export default function Tienda() {
  const [categoriaActiva, setCategoriaActiva] = useState('planes');

  const agregarAlCarrito = (producto) => {
    const actualizado = agregarProducto(leerCarrito(), producto);
    guardarCarrito(actualizado);
    alert(`¡"${producto.nombre}" agregado al carrito!`);
  };

  const productosFiltrados = PRODUCTOS.filter((p) => p.categoria === categoriaActiva);

  return (
    <main>
      <section className="hero">
        <div className="contenedor">
          <div>
            <p className="hero-eyebrow">Planes Funerarios</p>
            <h1>Planes Funerarios</h1>
            <p>
              Todos nuestros productos se pueden reservar en línea. Un asesor confirmará contigo los detalles y la forma de pago antes de coordinar la entrega o instalación.
            </p>
          </div>
          <div className="hero-imagen">
            <img src="/img/arregloFloral.jpg" alt="Arreglo floral blanco sobre mesa de madera" />
          </div>
        </div>
      </section>

      <section className="seccion">
        <div className="contenedor">
          <div className="seccion-titulo">
            <h2>Catálogo</h2>
          </div>

          <FiltroCategorias
            categorias={CATEGORIAS}
            activa={categoriaActiva}
            onCambiar={setCategoriaActiva}
          />

          {/* 1 columna en celular, 2 en tablet y 3 en escritorio */}
          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4" id="grid-productos">
            {productosFiltrados.map((prod) => (
              <div key={prod.id} className="col">
                <ProductoCard producto={prod} onAgregar={agregarAlCarrito} />
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
