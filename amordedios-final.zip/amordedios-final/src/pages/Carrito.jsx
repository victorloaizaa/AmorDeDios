import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import ItemCarrito from '../components/ItemCarrito';
import {
  leerCarrito,
  guardarCarrito,
  cambiarCantidad,
  eliminarProducto,
  calcularTotal,
  formatearPrecio,
} from '../utils/carrito';

export default function Carrito() {
  // el carrito parte con lo que se agregó desde la Tienda
  const [items, setItems] = useState(leerCarrito);

  const actualizarCarrito = (nuevosItems) => {
    setItems(nuevosItems);
    guardarCarrito(nuevosItems);
  };

  const handleCambiarCantidad = (id, delta) => {
    actualizarCarrito(cambiarCantidad(items, id, delta));
  };

  const handleEliminar = (id) => {
    actualizarCarrito(eliminarProducto(items, id));
  };

  const handleCheckout = () => {
    alert('¡Reserva procesada con éxito! Un asesor de Funeraria Amor de Dios se pondrá en contacto contigo a la brevedad.');
    actualizarCarrito([]);
  };

  const total = calcularTotal(items);

  return (
    <main>
      <section className="hero">
        <div className="contenedor">
          <div>
            <p className="hero-eyebrow">Resumen de Selección</p>
            <h1>Carrito de Servicios</h1>
            <p>Revisa los planes y productos seleccionados antes de confirmar tu reserva.</p>
          </div>
        </div>
      </section>

      <section className="seccion">
        <div className="contenedor">
          {items.length === 0 ? (
            <div className="text-center py-5 px-3">
              <h2>Tu carrito está vacío</h2>
              <p className="text-muted my-3">Aún no has agregado ningún plan o producto.</p>
              <Link to="/tienda" className="btn btn-dark btn-lg">Ver Planes Funerarios</Link>
            </div>
          ) : (
            <div className="row g-4">
              {/* lista de productos: todo el ancho en celular, 8 de 12 columnas en escritorio */}
              <div className="col-12 col-lg-8">
                <div className="card border-0 shadow-sm">
                  <div className="card-body p-3 p-md-4">
                    <h2 className="h4 mb-4">Servicios y Productos Seleccionados</h2>
                    <ul className="list-group list-group-flush">
                      {items.map((item) => (
                        <ItemCarrito
                          key={item.id}
                          item={item}
                          onCambiarCantidad={handleCambiarCantidad}
                          onEliminar={handleEliminar}
                        />
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* resumen: abajo en celular y a la derecha en escritorio */}
              <div className="col-12 col-lg-4">
                <div className="card border-0 shadow-sm resumen-carrito">
                  <div className="card-body p-4">
                    <p className="text-muted mb-1">Total Estimado Reserva:</p>
                    <p className="h2 mb-4" data-testid="total">{formatearPrecio(total)}</p>
                    <div className="d-grid gap-2">
                      <button type="button" onClick={handleCheckout} className="btn btn-dark btn-lg">CONFIRMAR RESERVA</button>
                      <button type="button" onClick={() => actualizarCarrito([])} className="btn btn-outline-secondary">Vaciar Carrito</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
