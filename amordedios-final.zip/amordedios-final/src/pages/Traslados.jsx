import React from 'react';

export default function Traslados() {
  return (
    <main>
      <section className="hero">
        <div className="contenedor">
          <div>
            <p className="hero-eyebrow">Servicios Especializados</p>
            <h1>Traslados Nacionales e Internacionales</h1>
            <p>Servicio de transporte protocolar y gestión de salvoconductos para traslados dentro de Chile y repatriaciones.</p>
          </div>
          <div className="hero-imagen">
            <img src="/img/autosFlota.jpg" alt="Flota de Carrozas y Vehículos" />
          </div>
        </div>
      </section>
      <section className="seccion">
        <div className="contenedor">
          <h2>Flota Móvil y Cobertura</h2>
          <p>Contamos con carros ceremoniales de gala, van familiares y trámites de aduana o SEREMI para traslados interregionales e internacionales.</p>
        </div>
      </section>
    </main>
  );
}