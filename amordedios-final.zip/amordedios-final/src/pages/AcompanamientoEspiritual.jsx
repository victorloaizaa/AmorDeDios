import React from 'react';
import { Link } from 'react-router-dom';

export default function AcompanamientoEspiritual() {
  return (
    <main style={{ paddingBottom: '3rem' }}>
      {/* SECCIÓN HERO */}
      <section className="hero">
        <div className="contenedor" style={{ textAlign: 'center' }}>
          <span style={{
            background: '#fdf8e7',
            color: '#b38f28',
            padding: '0.4rem 1.2rem',
            borderRadius: '20px',
            fontSize: '0.85rem',
            fontWeight: 'bold',
            letterSpacing: '1px',
            display: 'inline-block',
            marginBottom: '0.8rem',
            border: '1px solid #e2d192'
          }}>
            SERVICIOS ESPIRITUALES
          </span>
          <h1 style={{ fontSize: '2.5rem', color: '#1b263b', marginBottom: '1rem', fontFamily: 'serif' }}>
            Acompañamiento Espiritual y Ceremonial
          </h1>
          <p style={{ maxWidth: '750px', margin: '0 auto', color: '#555', fontSize: '1.05rem', lineHeight: '1.6' }}>
            Respetamos todos los cultos, credos religiosos y tradiciones. Ofrecemos asistencia ecuménica o laica durante la despedida para honrar la memoria de tu ser querido con paz y dignidad.
          </p>
        </div>
      </section>

      {/* SECCIÓN PRINCIPAL DE CONTENIDO */}
      <section style={{ marginTop: '2.5rem' }}>
        <div className="contenedor">
          <div className="row row-cols-1 row-cols-md-2 g-4 align-items-center mb-5">
            {/* ILUSTRACIÓN/IMAGEN DE ACOMPAÑAMIENTO EN BASE64/SVG INCRUSTADO */}
            <div className="col">
              <div className="h-100" style={{ borderRadius: '16px', overflow: 'hidden', boxShadow: '0 8px 25px rgba(0,0,0,0.08)', background: '#fdfbf7', padding: '1rem', border: '1px solid #e2d192', textAlign: 'center' }}>
                <svg viewBox="0 0 500 350" style={{ width: '100%', height: 'auto', maxHeight: '380px', display: 'block' }}>
                  <rect width="500" height="350" rx="12" fill="#f8f4eb"/>
                  <circle cx="250" cy="140" r="80" fill="#e8ded0" opacity="0.6"/>
                  <path d="M 180,220 C 200,160 230,130 250,130 C 270,130 300,160 320,220" fill="none" stroke="#d4af37" strokeWidth="6" strokeLinecap="round"/>
                  {/* Manos simbólicas de contención */}
                  <path d="M 150,230 Q 200,180 250,210 Q 280,220 310,200 Q 330,190 350,210 Q 300,260 240,250 Q 180,240 150,230 Z" fill="#cda851" opacity="0.85"/>
                  <path d="M 350,230 Q 300,180 250,210 Q 220,220 190,200 Q 170,190 150,210 Q 200,260 260,250 Q 320,240 350,230 Z" fill="#b8933b"/>
                  <text x="250" y="300" textAnchor="middle" fill="#1b263b" fontSize="18" fontFamily="serif" fontWeight="bold">Apoyo y Consuelo Espiritual</text>
                  <text x="250" y="322" textAnchor="middle" fill="#666" fontSize="13">Funeraria Amor de Dios</text>
                </svg>
              </div>
            </div>

            {/* Texto Descriptivo */}
            <div className="col">
              <div className="h-100">
                <h2 style={{ fontSize: '1.8rem', color: '#1b263b', fontFamily: 'serif', marginBottom: '1rem' }}>
                  Respeto Absoluto por Cada Creencia
                </h2>
                <p style={{ color: '#444', lineHeight: '1.7', marginBottom: '1.2rem', fontSize: '0.98rem' }}>
                  En Funeraria Amor de Dios entendemos que la dimensión espiritual es fundamental para brindar tranquilidad a las familias en momentos de duelo. Nos adaptamos rigurosamente a las preferencias litúrgicas y espirituales requeridas.
                </p>
                <p style={{ color: '#444', lineHeight: '1.7', marginBottom: '1.5rem', fontSize: '0.98rem' }}>
                  Coordinamos directamente con sacerdotes, pastores, guías espirituales o facilitadores de ceremonias laicas para asegurar un servicio respetuoso y cargado de emotividad.
                </p>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '1.2rem' }}>✓</span>
                    <span style={{ color: '#333', fontSize: '0.95rem' }}>Liturgias Católicas y Misas de Cuerpo Presente</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '1.2rem' }}>✓</span>
                    <span style={{ color: '#333', fontSize: '0.95rem' }}>Servicios Evangélicos y Protestantes</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '1.2rem' }}>✓</span>
                    <span style={{ color: '#333', fontSize: '0.95rem' }}>Homenajes Laicos y Ceremonias Simbólicas</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '1.2rem' }}>✓</span>
                    <span style={{ color: '#333', fontSize: '0.95rem' }}>Atención Personalizada a Diversas Comunidades Religiosas</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* TARJETAS DE CARACTERÍSTICAS DEL SERVICIO */}
          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 mb-5">
            <div className="col">
              <div className="h-100" style={{
                background: '#ffffff',
                padding: '1.8rem',
                borderRadius: '12px',
                border: '1px solid #e8e2ce',
                boxShadow: '0 4px 15px rgba(0,0,0,0.04)'
              }}>
                <h3 style={{ color: '#1b263b', fontFamily: 'serif', fontSize: '1.25rem', marginBottom: '0.8rem' }}>
                  Coordinación Clerical
                </h3>
                <p style={{ color: '#666', fontSize: '0.92rem', lineHeight: '1.6' }}>
                  Gestionamos la presencia de ministros religiosos o sacerdotes para responsos en velatorios, capillas o camposantos.
                </p>
              </div>
            </div>

            <div className="col">
              <div className="h-100" style={{
                background: '#ffffff',
                padding: '1.8rem',
                borderRadius: '12px',
                border: '1px solid #e8e2ce',
                boxShadow: '0 4px 15px rgba(0,0,0,0.04)'
              }}>
                <h3 style={{ color: '#1b263b', fontFamily: 'serif', fontSize: '1.25rem', marginBottom: '0.8rem' }}>
                  Música y Coros Sacros
                </h3>
                <p style={{ color: '#666', fontSize: '0.92rem', lineHeight: '1.6' }}>
                  Disponibilidad de acompañamiento musical ceremonial, solistas o arreglos acústicos solemnes para el responso.
                </p>
              </div>
            </div>

            <div className="col">
              <div className="h-100" style={{
                background: '#ffffff',
                padding: '1.8rem',
                borderRadius: '12px',
                border: '1px solid #e8e2ce',
                boxShadow: '0 4px 15px rgba(0,0,0,0.04)'
              }}>
                <h3 style={{ color: '#1b263b', fontFamily: 'serif', fontSize: '1.25rem', marginBottom: '0.8rem' }}>
                  Asesoría en Liturgia
                </h3>
                <p style={{ color: '#666', fontSize: '0.92rem', lineHeight: '1.6' }}>
                  Guiamos a la familia en la preparación de lecturas, recordatorios y detalles de la despedida religiosa.
                </p>
              </div>
            </div>
          </div>

          {/* BANNER DE ATENCIÓN Y CONTACTO */}
          <div style={{
            background: 'linear-gradient(135deg, #0b1321 0%, #1b263b 100%)',
            borderRadius: '16px',
            padding: '2.5rem',
            textAlign: 'center',
            color: '#ffffff',
            boxShadow: '0 8px 25px rgba(0,0,0,0.15)',
            border: '1px solid #d4af37'
          }}>
            <h2 style={{ fontSize: '1.8rem', color: '#d4af37', fontFamily: 'serif', marginBottom: '1rem' }}>
              ¿Necesitas coordinar un servicio o responso espiritual?
            </h2>
            <p style={{ maxWidth: '650px', margin: '0 auto 1.8rem', color: '#e0e0e0', fontSize: '1rem', lineHeight: '1.6' }}>
              Nuestros asesores están disponibles las 24 horas del día para responder todas tus consultas y coordinar los detalles que tu familia necesite.
            </p>
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <Link to="/contacto" className="boton" style={{ padding: '0.85rem 2rem', fontSize: '0.95rem' }}>
                CONTACTAR A UN ASESOR
              </Link>
              <Link to="/tienda" style={{
                padding: '0.85rem 2rem',
                fontSize: '0.95rem',
                borderRadius: '8px',
                border: '1px solid #d4af37',
                color: '#d4af37',
                textDecoration: 'none',
                fontWeight: 'bold'
              }}>
                VER PLANES FUNERARIOS
              </Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}