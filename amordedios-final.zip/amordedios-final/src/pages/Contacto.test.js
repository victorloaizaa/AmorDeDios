import { render, screen, fireEvent } from '@testing-library/react';
import Contacto from './Contacto';

const escribir = (id, valor) => fireEvent.change(document.getElementById(id), { target: { value: valor } });
const enviar = () => fireEvent.click(screen.getByRole('button', { name: 'Enviar Mensaje' }));

describe('Contacto - validación del formulario', () => {
  it('si se envía vacío marca los 4 campos obligatorios con error', () => {
    const { container } = render(<Contacto />);

    enviar();

    expect(container.querySelectorAll('.is-invalid').length).toBe(4);
    expect(screen.getByText('Ingresa tu nombre completo (mínimo 3 caracteres).')).toBeDefined();
    expect(screen.getByText('Selecciona el plan que más te interesa.')).toBeDefined();
    expect(document.getElementById('confirmacion')).toBeNull();
  });

  it('valida el correo al salir del campo (blur)', () => {
    render(<Contacto />);

    escribir('correo', 'maria.correo.cl');
    fireEvent.blur(document.getElementById('correo'));

    expect(document.getElementById('correo').className).toContain('is-invalid');
    expect(document.getElementById('error-correo').textContent).toContain('correo válido');
  });

  it('el error se borra mientras el usuario corrige el campo', () => {
    render(<Contacto />);

    enviar();
    escribir('telefono', '+56 9 1234 5678');

    expect(document.getElementById('telefono').className).toContain('is-valid');
    expect(document.getElementById('error-telefono').textContent).toBe('');
  });

  it('con datos correctos muestra la confirmación y limpia el formulario', () => {
    render(<Contacto />);

    escribir('nombre', 'María González');
    escribir('correo', 'maria@correo.cl');
    escribir('telefono', '+56 9 1234 5678');
    escribir('plan', 'premium');
    enviar();

    expect(document.getElementById('confirmacion')).not.toBeNull();
    expect(document.getElementById('nombre').value).toBe('');
  });

  it('el contador de caracteres sigue lo que se escribe en el mensaje', () => {
    render(<Contacto />);

    escribir('mensaje', 'Hola, necesito información');

    expect(document.getElementById('contador-mensaje').textContent).toBe('26');
  });
});
