import React from 'react';
import { Link } from 'react-router-dom';
import ServicioCard from '../components/ServicioCard';

export default function Servicios() {
  const serviciosPrincipales = [
    {
      id: 'velatorio-capilla',
      titulo: 'Velatorio y Capilla',
      descripcion: 'Salas especialmente preparadas para brindar un ambiente íntimo, sereno y acogedor para las familias.',
      link: '/velatorio-capilla',
      badge: 'Atención 24/7'
    },
    {
      id: 'cremacion',
      titulo: 'Cremación',
      descripcion: 'Proceso certificado con los más altos estándares de respeto, solemnidad y posterior entrega de cenizas.',
      link: '/cremacion',
      badge: 'Certificado'
    },
    {
      id: 'prearreglos',
      titulo: 'Prearreglos Funerarios',
      descripcion: 'Planifica con anticipación para dar tranquilidad a tus seres queridos y fijar costos a valor presente.',
      link: '/prearreglos',
      badge: 'Planificación'
    }
  ];

  const serviciosComplementarios = [
    {
      id: 'floristeria',
      titulo: 'Floristería y Arreglos',
      descripcion: 'Coronas, ramos y arreglos florales de distinción con entrega directa e inmediata en sala de velatorio.',
      link: '/tienda'
    },
    {
      id: 'traslados',
      titulo: 'Traslados Nacionales e Internacionales',
      descripcion: 'Coordinación y logística completa para el traslado del ser querido hacia cualquier destino con total custodia.',
      link: '/contacto'
    },
    {
      id: 'tramites',
      titulo: 'Trámites y Documentación',
      descripcion: 'Asesoría legal y gestión completa de pases de sepultura, certificados de defunción y trámites ante instituciones.',
      link: '/tramites-documentacion'
    }
  ];

  return (
    <main style={{ background: '#fcfbf7', minHeight: '100vh', paddingBottom: '5rem' }}>
      {/* ENCABEZADO PRINCIPAL DE LA PÁGINA */}
      <section style={{
        background: 'linear-gradient(180deg, #0b1321 0%, #1b263b 100%)',
        color: '#ffffff',
        padding: '3.5rem 1.5rem 3rem',
        textAlign: 'center',
        borderBottom: '2px solid #d4af37'
      }}>
        <div style={{ maxWidth: '900px', margin: '0 auto' }}>
          <span style={{
            background: 'rgba(212, 175, 55, 0.15)',
            color: '#d4af37',
            border: '1px solid #d4af37',
            padding: '0.4rem 1.5rem',
            borderRadius: '20px',
            fontSize: '0.85rem',
            fontWeight: 'bold',
            letterSpacing: '2px',
            display: 'inline-block',
            marginBottom: '1rem'
          }}>
            COBERTURA E INTEGRALIDAD EXEQUIAL
          </span>
          <h1 style={{ fontSize: '2.5rem', fontFamily: 'serif', color: '#ffffff', margin: '0 0 1rem' }}>
            Nuestros Servicios Funerarios
          </h1>
          <p style={{ fontSize: '1.1rem', color: '#cbd5e1', lineHeight: '1.7', margin: '0 auto', maxWidth: '700px' }}>
            Acompañamos a las familias con calidez, transparencia, respeto y total dignidad en cada paso de este proceso.
          </p>
        </div>
      </section>

      {/* SECCIÓN 1: SERVICIOS PRINCIPALES */}
      <section style={{ padding: '4rem 1.5rem 2rem' }}>
        <div style={{ maxWidth: '1150px', margin: '0 auto' }}>
          <div style={{ marginBottom: '2.5rem', borderLeft: '4px solid #d4af37', paddingLeft: '1rem' }}>
            <h2 style={{ fontSize: '1.8rem', color: '#1b263b', fontFamily: 'serif', margin: 0 }}>
              Servicios Principales
            </h2>
            <p style={{ color: '#666', fontSize: '0.95rem', margin: '0.3rem 0 0' }}>
              Soluciones fundamentales diseñadas para brindar homenajes con la máxima solemnidad.
            </p>
          </div>

          {/* 1 por fila en celular, 2 desde tablet */}
          <div className="row row-cols-1 row-cols-md-2 g-4">
            {serviciosPrincipales.map((servicio) => (
              <div key={servicio.id} className="col">
                <ServicioCard
                  titulo={servicio.titulo}
                  descripcion={servicio.descripcion}
                  link={servicio.link}
                  badge={servicio.badge}
                  destacado
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECCIÓN 2: SERVICIOS COMPLEMENTARIOS */}
      <section style={{ padding: '3rem 1.5rem 4rem' }}>
        <div style={{ maxWidth: '1150px', margin: '0 auto' }}>
          <div style={{ marginBottom: '2.5rem', borderLeft: '4px solid #1b263b', paddingLeft: '1rem' }}>
            <h2 style={{ fontSize: '1.8rem', color: '#1b263b', fontFamily: 'serif', margin: 0 }}>
              Servicios Complementarios
            </h2>
            <p style={{ color: '#666', fontSize: '0.95rem', margin: '0.3rem 0 0' }}>
              Asistencia logística, legal y elementos conmemorativos para un apoyo integral.
            </p>
          </div>

          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            {serviciosComplementarios.map((servicio) => (
              <div key={servicio.id} className="col">
                <ServicioCard {...servicio} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BANNER DE ATENCIÓN DE EMERGENCIA */}
      <section style={{ padding: '2rem 1.5rem' }}>
        <div style={{ maxWidth: '950px', margin: '0 auto' }}>
          <div style={{
            background: 'linear-gradient(135deg, #0b1321 0%, #1b263b 100%)',
            borderRadius: '16px',
            padding: '2.5rem',
            textAlign: 'center',
            color: '#ffffff',
            boxShadow: '0 10px 30px rgba(0,0,0,0.15)',
            border: '1px solid #d4af37'
          }}>
            <h2 style={{ fontSize: '2rem', color: '#d4af37', fontFamily: 'serif', marginBottom: '0.8rem' }}>
              ¿Necesitas orientación inmediata?
            </h2>
            <p style={{ maxWidth: '650px', margin: '0 auto 1.8rem', color: '#cbd5e1', fontSize: '1.02rem', lineHeight: '1.6' }}>
              Estamos disponibles las 24 horas para guiarte en la elección del servicio adecuado para tu familia.
            </p>
            <Link to="/contacto" className="boton" style={{ padding: '0.9rem 2.5rem', fontSize: '0.95rem' }}>
              CONTACTAR A UN ASESOR EN VIVO
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}