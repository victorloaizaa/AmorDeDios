import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export default function Home() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      id: 1,
      url: '/img/logoFuneraria.jpg',
      titulo: 'PLANES A TU MEDIDA',
      subtitulo: 'Acompañándote con serenidad, transparencia y dignidad en todo momento.'
    },
    {
      id: 2,
      url: '/img/presentacion1.jpg',
      titulo: 'ATENCIÓN LAS 24 HORAS',
      subtitulo: 'Un equipo humano y profesional disponible en el momento que nos necesites.'
    },
    {
      id: 3,
      url: '/img/presentacion2.jpg',
      titulo: 'CREMACIÓN Y CAPILLAS',
      subtitulo: 'Espacios serenos e infraestructura preparada para honrar a tus seres queridos.'
    },
    {
      id: 4,
      url: '/img/presentacion3.jpg',
      titulo: 'COBERTURA Y TRASLADOS',
      subtitulo: 'Gestión integral y traslados dentro y fuera del país con máxima privacidad.'
    },
    {
      id: 5,
      url: '/img/velacion.jpg',
      titulo: 'ACOMPAÑAMIENTO INTEGRAL',
      subtitulo: 'Asistencia humana, contención emocional y asesoría en todo el proceso.'
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5500);
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <main>
      {/* SECCIÓN HERO / CARRUSEL PRINCIPAL */}
      <section style={{ position: 'relative', background: '#0b1321', overflow: 'hidden' }}>
        
        {/* CABECERA PRINCIPAL ESTILIZADA CON LOGO OFICIAL */}
        <div style={{
          background: 'linear-gradient(180deg, #0b1321 0%, rgba(11, 19, 33, 0.95) 100%)',
          padding: '2.5rem 1.5rem 1rem',
          textAlign: 'center',
          position: 'relative',
          zIndex: 2,
          borderBottom: '1px solid rgba(212, 175, 55, 0.25)'
        }}>
          
          {/* LOGO INSTITUCIONAL OFICIAL (Reemplaza el texto plano recargado) */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '1.2rem' }}>
            <img 
              src="/img/logoFuneraria.jpg" 
              alt="Logo Funeraria Amor de Dios" 
              style={{ 
                maxHeight: '65px', 
                width: 'auto', 
                objectFit: 'contain',
                filter: 'drop-shadow(0 4px 10px rgba(0,0,0,0.4))',
                borderRadius: '6px'
              }}
              onError={(e) => {
                // Resguardo elegante con sello sobrio si no carga el archivo del logo
                e.target.style.display = 'none';
              }}
            />
          </div>

          {/* BADGE DEL ESLOGAN OVALADO DORADO */}
          <span style={{
            background: 'rgba(212, 175, 55, 0.12)',
            color: '#d4af37',
            border: '1px solid #d4af37',
            padding: '0.4rem 1.8rem',
            borderRadius: '25px',
            fontSize: '0.85rem',
            fontWeight: '600',
            letterSpacing: '2.5px',
            display: 'inline-block',
            marginBottom: '1rem',
            boxShadow: '0 2px 12px rgba(212, 175, 55, 0.15)'
          }}>
            {slides[currentSlide].titulo}
          </span>

          {/* SUBTÍTULO PRINCIPAL CON TIPOGRAFÍA SERIF ELEGANTE */}
          <h1 style={{ 
            fontSize: '2.2rem', 
            fontFamily: '"Cinzel", "Playfair Display", serif', 
            color: '#ffffff', 
            margin: '0 auto 1.2rem', 
            maxWidth: '850px',
            lineHeight: '1.3',
            fontWeight: '400'
          }}>
            {slides[currentSlide].subtitulo}
          </h1>

          {/* BOTONES DE ACCIÓN */}
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap', marginTop: '1.2rem' }}>
            <Link to="/contacto" className="boton" style={{ padding: '0.85rem 2.2rem', fontSize: '0.92rem', letterSpacing: '0.5px' }}>
              CONTACTAR A UN ASESOR
            </Link>
            <Link to="/tienda" style={{
              padding: '0.85rem 2.2rem',
              fontSize: '0.92rem',
              borderRadius: '8px',
              border: '1px solid #d4af37',
              color: '#d4af37',
              textDecoration: 'none',
              fontWeight: 'bold',
              letterSpacing: '0.5px',
              transition: 'all 0.3s ease'
            }}>
              VER PLANES FUNERARIOS
            </Link>
          </div>
        </div>

        {/* CONTENEDOR DEL CARRUSEL ADAPTATIVO CON FONDO DIFUMINADO */}
        <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '1rem 1.5rem 2.5rem', position: 'relative' }}>
          <div style={{
            borderRadius: '16px',
            overflow: 'hidden',
            boxShadow: '0 15px 40px rgba(0,0,0,0.65)',
            border: '1px solid rgba(212, 175, 55, 0.5)',
            height: '480px',
            position: 'relative',
            background: '#0b1321'
          }}>
            {/* 1. FONDO DIFUMINADO (BLUR BACKDROP) */}
            <div style={{
              position: 'absolute',
              inset: 0,
              backgroundImage: `url(${slides[currentSlide].url})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              filter: 'blur(20px) brightness(0.35)',
              transform: 'scale(1.12)',
              transition: 'background-image 0.6s ease-in-out'
            }} />

            {/* 2. IMAGEN VERTICAL CENTRAL NÍTIDA */}
            <div style={{
              position: 'relative',
              width: '100%',
              height: '100%',
              display: 'flex',
              alignItems: 'center',
              justify: 'center',
              zIndex: 2,
              padding: '1.2rem'
            }}>
              <img 
                src={slides[currentSlide].url} 
                alt={`Diapositiva ${slides[currentSlide].id}`}
                style={{
                  maxHeight: '100%',
                  maxWidth: '100%',
                  objectFit: 'contain',
                  borderRadius: '10px',
                  boxShadow: '0 10px 30px rgba(0,0,0,0.6)',
                  transition: 'opacity 0.4s ease-in-out'
                }}
              />
            </div>

            {/* CONTROLES NAVEGADORES */}
            <button
              type="button"
              aria-label="Diapositiva anterior"
              onClick={() => setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1))}
              style={{
                position: 'absolute',
                left: '18px',
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'rgba(11, 19, 33, 0.85)',
                color: '#d4af37',
                border: '1px solid #d4af37',
                borderRadius: '50%',
                width: '45px',
                height: '45px',
                cursor: 'pointer',
                fontSize: '1.4rem',
                fontWeight: 'bold',
                zIndex: 10,
                boxShadow: '0 4px 12px rgba(0,0,0,0.4)'
              }}
            >
              ‹
            </button>

            <button
              type="button"
              aria-label="Diapositiva siguiente"
              onClick={() => setCurrentSlide((prev) => (prev + 1) % slides.length)}
              style={{
                position: 'absolute',
                right: '18px',
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'rgba(11, 19, 33, 0.85)',
                color: '#d4af37',
                border: '1px solid #d4af37',
                borderRadius: '50%',
                width: '45px',
                height: '45px',
                cursor: 'pointer',
                fontSize: '1.4rem',
                fontWeight: 'bold',
                zIndex: 10,
                boxShadow: '0 4px 12px rgba(0,0,0,0.4)'
              }}
            >
              ›
            </button>

            {/* INDICADORES DE PUNTOS */}
            <div style={{
              position: 'absolute',
              bottom: '15px',
              left: '50%',
              transform: 'translateX(-50%)',
              display: 'flex',
              gap: '0.6rem',
              zIndex: 10
            }}>
              {slides.map((_, idx) => (
                <div
                  key={idx}
                  role="button"
                  aria-label={`Ir a la diapositiva ${idx + 1}`}
                  onClick={() => setCurrentSlide(idx)}
                  style={{
                    width: idx === currentSlide ? '28px' : '10px',
                    height: '10px',
                    borderRadius: '5px',
                    background: idx === currentSlide ? '#d4af37' : 'rgba(255,255,255,0.4)',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease'
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SECCIÓN 1: CÓMO PODEMOS AYUDARTE */}
      <section style={{ padding: '4.5rem 0', background: '#fcfbf7' }}>
        <div className="contenedor">
          <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
            <span style={{ color: '#b38f28', fontWeight: 'bold', letterSpacing: '1.5px', fontSize: '0.85rem', textTransform: 'uppercase' }}>
              SERVICIOS EXEQUIALES
            </span>
            <h2 style={{ fontSize: '2.2rem', color: '#1b263b', fontFamily: 'serif', marginTop: '0.4rem' }}>
              ¿Cómo podemos ayudarte?
            </h2>
          </div>

          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <div className="col">
              <div className="h-100" style={{
                background: '#ffffff',
                borderRadius: '12px',
                padding: '2.2rem',
                border: '1px solid #e8e2ce',
                boxShadow: '0 4px 18px rgba(0,0,0,0.04)',
                display: 'flex',
                flexDirection: 'column',
                justify: 'space-between'
              }}>
                <div>
                  <h3 style={{ fontSize: '1.35rem', color: '#1b263b', fontFamily: 'serif', marginBottom: '0.8rem', borderBottom: '2px solid #d4af37', paddingBottom: '0.4rem', display: 'inline-block' }}>
                    Velatorio y Capilla
                  </h3>
                  <p style={{ color: '#555', fontSize: '0.93rem', lineHeight: '1.6', marginBottom: '1.5rem' }}>
                    Salas propias y capilla ecuménica preparadas para despedirte con calma y absoluta privacidad.
                  </p>
                </div>
                <Link to="/velatorio-capilla" style={{ color: '#d4af37', fontWeight: 'bold', textDecoration: 'none', fontSize: '0.9rem' }}>
                  Ver más información →
                </Link>
              </div>
            </div>

            <div className="col">
              <div className="h-100" style={{
                background: '#ffffff',
                borderRadius: '12px',
                padding: '2.2rem',
                border: '1px solid #e8e2ce',
                boxShadow: '0 4px 18px rgba(0,0,0,0.04)',
                display: 'flex',
                flexDirection: 'column',
                justify: 'space-between'
              }}>
                <div>
                  <h3 style={{ fontSize: '1.35rem', color: '#1b263b', fontFamily: 'serif', marginBottom: '0.8rem', borderBottom: '2px solid #d4af37', paddingBottom: '0.4rem', display: 'inline-block' }}>
                    Cremación
                  </h3>
                  <p style={{ color: '#555', fontSize: '0.93rem', lineHeight: '1.6', marginBottom: '1.5rem' }}>
                    Proceso certificado con entrega de cenizas a la familia en ceremonia íntima y respetuosa.
                  </p>
                </div>
                <Link to="/cremacion" style={{ color: '#d4af37', fontWeight: 'bold', textDecoration: 'none', fontSize: '0.9rem' }}>
                  Ver más información →
                </Link>
              </div>
            </div>

            <div className="col">
              <div className="h-100" style={{
                background: '#ffffff',
                borderRadius: '12px',
                padding: '2.2rem',
                border: '1px solid #e8e2ce',
                boxShadow: '0 4px 18px rgba(0,0,0,0.04)',
                display: 'flex',
                flexDirection: 'column',
                justify: 'space-between'
              }}>
                <div>
                  <h3 style={{ fontSize: '1.35rem', color: '#1b263b', fontFamily: 'serif', marginBottom: '0.8rem', borderBottom: '2px solid #d4af37', paddingBottom: '0.4rem', display: 'inline-block' }}>
                    Prearreglos
                  </h3>
                  <p style={{ color: '#555', fontSize: '0.93rem', lineHeight: '1.6', marginBottom: '1.5rem' }}>
                    Planifica en vida y da tranquilidad a los tuyos fijando costos ante eventos futuros.
                  </p>
                </div>
                <Link to="/prearreglos" style={{ color: '#d4af37', fontWeight: 'bold', textDecoration: 'none', fontSize: '0.9rem' }}>
                  Ver más información →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECCIÓN 2: MÁS QUE UN SERVICIO FUNERARIO */}
      <section style={{ padding: '4.5rem 0', background: '#f4f1ea', borderTop: '1px solid #e2d192', borderBottom: '1px solid #e2d192' }}>
        <div className="contenedor">
          <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
            <span style={{ color: '#b38f28', fontWeight: 'bold', letterSpacing: '1.5px', fontSize: '0.85rem', textTransform: 'uppercase' }}>
              COMPROMISO HUMANO Y SOCIAL
            </span>
            <h2 style={{ fontSize: '2.2rem', color: '#1b263b', fontFamily: 'serif', marginTop: '0.4rem' }}>
              Más que un servicio funerario
            </h2>
          </div>

          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <div className="col">
              <div className="h-100" style={{
                background: '#ffffff',
                borderRadius: '12px',
                padding: '2rem',
                border: '1px solid #e2d192',
                boxShadow: '0 4px 15px rgba(0,0,0,0.03)',
                display: 'flex',
                flexDirection: 'column',
                justify: 'space-between'
              }}>
                <div>
                  <h3 style={{ fontSize: '1.3rem', color: '#1b263b', fontFamily: 'serif', marginBottom: '0.8rem' }}>
                    Acompañamiento Espiritual
                  </h3>
                  <p style={{ color: '#555', fontSize: '0.93rem', lineHeight: '1.6', marginBottom: '1.5rem' }}>
                    Ceremonias según tus creencias y ritos religiosos o laicos con la máxima solemnidad.
                  </p>
                </div>
                <Link to="/acompanamiento-espiritual" style={{ color: '#1b263b', fontWeight: 'bold', textDecoration: 'none', fontSize: '0.9rem' }}>
                  Ver más detalles →
                </Link>
              </div>
            </div>

            <div className="col">
              <div className="h-100" style={{
                background: '#ffffff',
                borderRadius: '12px',
                padding: '2rem',
                border: '1px solid #e2d192',
                boxShadow: '0 4px 15px rgba(0,0,0,0.03)',
                display: 'flex',
                flexDirection: 'column',
                justify: 'space-between'
              }}>
                <div>
                  <h3 style={{ fontSize: '1.3rem', color: '#1b263b', fontFamily: 'serif', marginBottom: '0.8rem' }}>
                    Contención Emocional
                  </h3>
                  <p style={{ color: '#555', fontSize: '0.93rem', lineHeight: '1.6', marginBottom: '1.5rem' }}>
                    Apoyo psicológico y humano para acompañar a la familia en el proceso de duelo.
                  </p>
                </div>
                <Link to="/contencion-emocional" style={{ color: '#1b263b', fontWeight: 'bold', textDecoration: 'none', fontSize: '0.9rem' }}>
                  Ver más detalles →
                </Link>
              </div>
            </div>

            <div className="col">
              <div className="h-100" style={{
                background: '#ffffff',
                borderRadius: '12px',
                padding: '2rem',
                border: '1px solid #e2d192',
                boxShadow: '0 4px 15px rgba(0,0,0,0.03)',
                display: 'flex',
                flexDirection: 'column',
                justify: 'space-between'
              }}>
                <div>
                  <h3 style={{ fontSize: '1.3rem', color: '#1b263b', fontFamily: 'serif', marginBottom: '0.8rem' }}>
                    Fundación Amor de Dios
                  </h3>
                  <p style={{ color: '#555', fontSize: '0.93rem', lineHeight: '1.6', marginBottom: '1.5rem' }}>
                    Ayuda e integración exequial para familias en situación de vulnerabilidad.
                  </p>
                </div>
                <Link to="/nosotros" style={{ color: '#1b263b', fontWeight: 'bold', textDecoration: 'none', fontSize: '0.9rem' }}>
                  Ver más detalles →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* BANNER FINAL */}
      <section style={{ padding: '4rem 1.5rem', background: '#fcfbf7' }}>
        <div className="contenedor" style={{ maxWidth: '950px', margin: '0 auto' }}>
          <div style={{
            background: 'linear-gradient(135deg, #0b1321 0%, #1b263b 100%)',
            borderRadius: '16px',
            padding: '2.5rem',
            textAlign: 'center',
            color: '#ffffff',
            boxShadow: '0 10px 30px rgba(0,0,0,0.15)',
            border: '1px solid #d4af37'
          }}>
            <h2 style={{ fontSize: '2.1rem', color: '#d4af37', fontFamily: 'serif', marginBottom: '0.8rem' }}>
              ¿Necesitas ayuda ahora?
            </h2>
            <p style={{ maxWidth: '650px', margin: '0 auto 1.8rem', color: '#cbd5e1', fontSize: '1.05rem', lineHeight: '1.6' }}>
              Nuestro equipo está disponible las 24 horas para acompañarte en este proceso.
            </p>
            <Link to="/contacto" className="boton" style={{ padding: '0.95rem 2.5rem', fontSize: '1rem' }}>
              CONTACTAR A UN ASESOR
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}