import React from 'react';
import { Link } from 'react-router-dom';

export default function Sucursales() {
  const listaSucursales = [
    {
      id: 'cerrillos',
      comuna: 'Cerrillos',
      nombre: 'Sucursal Cerrillos - Casa Matriz',
      direccion: 'Las Galaxias 1752, Cerrillos, Región Metropolitana',
      telefono: '+56 2 2345 6789',
      horario: 'Atención presencial: Lunes a Domingo de 08:30 a 20:00 hrs. (Urgencias 24/7)',
      imagen: '/img/foto ubicacion.jpeg',
      fallbackImagen: '/img/foto_ubicacion.jpeg',
      mapaEmbed: 'https://maps.google.com/maps?q=Las%20Galaxias%201752,%20Cerrillos&t=&z=15&ie=UTF8&iwloc=&output=embed'
    },
    {
      id: 'providencia',
      comuna: 'Providencia',
      nombre: 'Sucursal Providencia',
      direccion: 'Av. Providencia 2150, Providencia, Región Metropolitana',
      telefono: '+56 2 2345 6790',
      horario: 'Atención presencial: Lunes a Viernes de 09:00 a 19:00 hrs.',
      imagen: '/img/foto ubicacion.jpeg',
      fallbackImagen: '/img/foto_ubicacion.jpeg',
      mapaEmbed: 'https://maps.google.com/maps?q=Av.%20Providencia%202150,%20Providencia&t=&z=15&ie=UTF8&iwloc=&output=embed'
    }
  ];

  return (
    <main style={{ background: '#fcfbf7', minHeight: '100vh', paddingBottom: '5rem' }}>
      {/* HEADER DE SUCURSALES */}
      <section style={{
        background: 'linear-gradient(180deg, #0b1321 0%, #1b263b 100%)',
        color: '#ffffff',
        padding: '3.5rem 1.5rem 3rem',
        textAlign: 'center',
        borderBottom: '2px solid #d4af37'
      }}>
        <div style={{ maxWidth: '900px', margin: '0 auto' }}>
          <span style={{
            background: 'rgba(212, 175, 55, 0.15)',
            color: '#d4af37',
            border: '1px solid #d4af37',
            padding: '0.4rem 1.5rem',
            borderRadius: '20px',
            fontSize: '0.85rem',
            fontWeight: 'bold',
            letterSpacing: '2px',
            display: 'inline-block',
            marginBottom: '1rem'
          }}>
            NUESTRA RED DE ATENCIÓN
          </span>
          <h1 style={{ fontSize: '2.5rem', fontFamily: 'serif', color: '#ffffff', margin: '0 0 1rem' }}>
            Nuestras Sucursales
          </h1>
          <p style={{ fontSize: '1.1rem', color: '#cbd5e1', lineHeight: '1.7', margin: '0 auto', maxWidth: '700px' }}>
            Contamos con instalaciones acogedoras y ubicaciones estratégicas para brindarte la mejor atención humana y profesional.
          </p>
        </div>
      </section>

      {/* LISTA DE SUCURSALES EN TARJETAS CON FOTO DE UBICACIÓN Y MAPA */}
      <section style={{ padding: '4rem 1.5rem' }}>
        <div style={{ maxWidth: '1150px', margin: '0 auto' }}>
          <div className="row row-cols-1 row-cols-md-2 g-4">
            {listaSucursales.map((sucursal) => (
              <div className="col" key={sucursal.id}>
                <div className="h-100"
                  style={{
                    background: '#ffffff',
                    borderRadius: '16px',
                    overflow: 'hidden',
                    border: '1px solid #e8e2ce',
                    boxShadow: '0 6px 20px rgba(0,0,0,0.05)',
                    display: 'flex',
                    flexDirection: 'column',
                    justify: 'space-between'
                  }}
                >
                  <div>
                    {/* FOTO OFICIAL DE UBICACIÓN Y TELÉFONO EN MANO */}
                    <div style={{ width: '100%', height: '220px', position: 'relative', overflow: 'hidden', background: '#0b1321' }}>
                      <img 
                        src={sucursal.imagen} 
                        alt={`Foto ubicación ${sucursal.nombre}`}
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                        onError={(e) => {
                          e.target.onerror = null;
                          e.target.src = sucursal.fallbackImagen;
                        }}
                      />
                      <div style={{
                        position: 'absolute',
                        inset: 0,
                        background: 'linear-gradient(180deg, rgba(11,19,33,0.1) 0%, rgba(11,19,33,0.7) 100%)'
                      }} />
                      <span style={{
                        position: 'absolute',
                        bottom: '12px',
                        left: '15px',
                        color: '#ffffff',
                        background: 'rgba(11, 19, 33, 0.85)',
                        border: '1px solid #d4af37',
                        padding: '0.3rem 0.8rem',
                        borderRadius: '6px',
                        fontSize: '0.8rem',
                        fontWeight: 'bold',
                        letterSpacing: '1px'
                      }}>
                        UBICACIÓN & ATENCIÓN 24/7
                      </span>
                    </div>

                    {/* MAPA INTERACTIVO DE GOOGLE */}
                    <div style={{ width: '100%', height: '180px', borderTop: '1px solid #e8e2ce' }}>
                      <iframe
                        title={`Mapa ${sucursal.nombre}`}
                        src={sucursal.mapaEmbed}
                        width="100%"
                        height="100%"
                        style={{ border: 0 }}
                        allowFullScreen=""
                        loading="lazy"
                      ></iframe>
                    </div>

                    {/* INFORMACIÓN DETALLADA DE LA SUCURSAL */}
                    <div style={{ padding: '2rem' }}>
                      <span style={{
                        color: '#b38f28',
                        fontWeight: 'bold',
                        fontSize: '0.8rem',
                        letterSpacing: '1px',
                        textTransform: 'uppercase'
                      }}>
                        {sucursal.comuna}
                      </span>

                      <h3 style={{
                        fontSize: '1.4rem',
                        color: '#1b263b',
                        fontFamily: 'serif',
                        marginTop: '0.3rem',
                        marginBottom: '1rem',
                        borderBottom: '2px solid #d4af37',
                        paddingBottom: '0.4rem',
                        display: 'inline-block'
                      }}>
                        {sucursal.nombre}
                      </h3>

                      <div style={{ color: '#555', fontSize: '0.95rem', lineHeight: '1.7' }}>
                        <p style={{ margin: '0 0 0.8rem', display: 'flex', gap: '0.5rem', alignItems: 'flex-start' }}>
                          <strong style={{ color: '#1b263b' }}>Dirección:</strong> {sucursal.direccion}
                        </p>
                        <p style={{ margin: '0 0 0.8rem', display: 'flex', gap: '0.5rem' }}>
                          <strong style={{ color: '#1b263b' }}>Teléfono:</strong> {sucursal.telefono}
                        </p>
                        <p style={{ margin: '0', display: 'flex', gap: '0.5rem', alignItems: 'flex-start' }}>
                          <strong style={{ color: '#1b263b' }}>Horario:</strong> {sucursal.horario}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div style={{ padding: '0 2rem 2rem' }}>
                    <Link
                      to="/contacto"
                      style={{
                        display: 'block',
                        textAlign: 'center',
                        background: '#0b1321',
                        color: '#d4af37',
                        padding: '0.8rem 1.5rem',
                        borderRadius: '8px',
                        textDecoration: 'none',
                        fontWeight: 'bold',
                        fontSize: '0.9rem',
                        border: '1px solid #d4af37',
                        transition: 'all 0.3s ease'
                      }}
                    >
                      Contactar a esta sucursal →
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BANNER 24/7 */}
      <section style={{ padding: '2rem 1.5rem' }}>
        <div style={{ maxWidth: '950px', margin: '0 auto' }}>
          <div style={{
            background: 'linear-gradient(135deg, #0b1321 0%, #1b263b 100%)',
            borderRadius: '16px',
            padding: '2.5rem',
            textAlign: 'center',
            color: '#ffffff',
            boxShadow: '0 10px 30px rgba(0,0,0,0.15)',
            border: '1px solid #d4af37'
          }}>
            <h2 style={{ fontSize: '2rem', color: '#d4af37', fontFamily: 'serif', marginBottom: '0.8rem' }}>
              Atención Telefónica 24/7
            </h2>
            <p style={{ maxWidth: '650px', margin: '0 auto 1.8rem', color: '#cbd5e1', fontSize: '1.02rem', lineHeight: '1.6' }}>
              Sin importar la hora o la sucursal, nuestro equipo de orientación te atenderá de forma inmediata.
            </p>
            <Link to="/contacto" className="boton" style={{ padding: '0.9rem 2.5rem', fontSize: '0.95rem' }}>
              CONTACTAR AHORA
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}