import React from 'react';
import { Link } from 'react-router-dom';

export default function ConveniosSeguros() {
  return (
    <main style={{ paddingBottom: '3rem' }}>
      {/* SECCIÓN HERO */}
      <section className="hero">
        <div className="contenedor" style={{ textAlign: 'center' }}>
          <span style={{
            background: '#fdf8e7',
            color: '#b38f28',
            padding: '0.4rem 1.2rem',
            borderRadius: '20px',
            fontSize: '0.85rem',
            fontWeight: 'bold',
            letterSpacing: '1px',
            display: 'inline-block',
            marginBottom: '0.8rem',
            border: '1px solid #e2d192'
          }}>
            BENEFICIOS Y ASISTENCIA
          </span>
          <h1 style={{ fontSize: '2.5rem', color: '#1b263b', marginBottom: '1rem', fontFamily: 'serif' }}>
            Convenios y Seguros Funerarios
          </h1>
          <p style={{ maxWidth: '750px', margin: '0 auto', color: '#555', fontSize: '1.05rem', lineHeight: '1.6' }}>
            Gestionamos la cuota mortuoria y asignaciones por muerte con AFP, IPS, FONASA, Fuerzas Armadas, sindicatos y compañías aseguradoras sin complicaciones.
          </p>
        </div>
      </section>

      {/* SECCIÓN PRINCIPAL DE CONTENIDO */}
      <section style={{ marginTop: '2.5rem' }}>
        <div className="contenedor">
          <div className="row row-cols-1 row-cols-md-2 g-4 align-items-center mb-5">
            {/* ILUSTRACIÓN/IMAGEN DE CONVENIOS EN SVG INCRUSTADO */}
            <div className="col">
              <div className="h-100" style={{ borderRadius: '16px', overflow: 'hidden', boxShadow: '0 8px 25px rgba(0,0,0,0.08)', background: '#fdfbf7', padding: '1rem', border: '1px solid #e2d192', textAlign: 'center' }}>
                <svg viewBox="0 0 500 350" style={{ width: '100%', height: 'auto', maxHeight: '380px', display: 'block' }}>
                  <rect width="500" height="350" rx="12" fill="#f8f6f0"/>
                  <circle cx="250" cy="140" r="85" fill="#eae3d2" opacity="0.8"/>
                  {/* Ícono de escudo / verificación de convenios */}
                  <path d="M 250,70 L 320,100 V 170 C 320,220 250,250 250,250 C 250,250 180,220 180,170 V 100 Z" fill="#1b263b"/>
                  <path d="M 220,150 L 240,170 L 280,130" stroke="#d4af37" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
                  <text x="250" y="295" textAnchor="middle" fill="#1b263b" fontSize="18" fontFamily="serif" fontWeight="bold">Gestión Integral de Beneficios</text>
                  <text x="250" y="318" textAnchor="middle" fill="#666" fontSize="13">AFP • IPS • Asignación Mortuoria • Seguros</text>
                </svg>
              </div>
            </div>

            {/* TEXTO DESCRIPTIVO */}
            <div className="col">
              <div className="h-100">
                <h2 style={{ fontSize: '1.8rem', color: '#1b263b', fontFamily: 'serif', marginBottom: '1rem' }}>
                  Cobro Directo de Cuota Mortuoria y Beneficios
                </h2>
                <p style={{ color: '#444', lineHeight: '1.7', marginBottom: '1.2rem', fontSize: '0.98rem' }}>
                  Nos encargamos de gestionar de forma directa la asignación por muerte o cuota mortuoria ante instituciones públicas y privadas, facilitando el trámite para que la familia no deba realizar desembolsos innecesarios de dinero.
                </p>
                <p style={{ color: '#444', lineHeight: '1.7', marginBottom: '1.5rem', fontSize: '0.98rem' }}>
                  Mantenemos convenios vigentes con empresas, sindicatos, asociaciones gremiales y aseguradoras, entregando valores preferenciales y facilidades de pago.
                </p>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '1.2rem' }}>✓</span>
                    <span style={{ color: '#333', fontSize: '0.95rem' }}>Tramitación directa ante todas las AFP e IPS</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '1.2rem' }}>✓</span>
                    <span style={{ color: '#333', fontSize: '0.95rem' }}>Convenios con FF.AA., Carabineros, CAPREDENA y DIPRECA</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '1.2rem' }}>✓</span>
                    <span style={{ color: '#333', fontSize: '0.95rem' }}>Aceptación de pólizas de Seguros de Vida y Asistencia</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ color: '#d4af37', fontWeight: 'bold', fontSize: '1.2rem' }}>✓</span>
                    <span style={{ color: '#333', fontSize: '0.95rem' }}>Descuentos corporativos para empresas y sindicatos</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* TARJETAS DE SERVICIOS */}
          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 mb-5">
            <div className="col">
              <div className="h-100" style={{ background: '#fff', padding: '1.8rem', borderRadius: '12px', border: '1px solid #e8e2ce', boxShadow: '0 4px 15px rgba(0,0,0,0.04)' }}>
                <h3 style={{ color: '#1b263b', fontFamily: 'serif', fontSize: '1.25rem', marginBottom: '0.8rem' }}>Gestión Sin Costo</h3>
                <p style={{ color: '#666', fontSize: '0.92rem', lineHeight: '1.6' }}>Nos ocupamos de realizar todo el papeleo administrativo ante la entidad pagadora sin cargos adicionales para la familia.</p>
              </div>
            </div>
            <div className="col">
              <div className="h-100" style={{ background: '#fff', padding: '1.8rem', borderRadius: '12px', border: '1px solid #e8e2ce', boxShadow: '0 4px 15px rgba(0,0,0,0.04)' }}>
                <h3 style={{ color: '#1b263b', fontFamily: 'serif', fontSize: '1.25rem', marginBottom: '0.8rem' }}>Compañías de Seguros</h3>
                <p style={{ color: '#666', fontSize: '0.92rem', lineHeight: '1.6' }}>Tramitamos pólizas de vida y asistencia funeraria con cobranza y liquidación directa con las aseguradoras.</p>
              </div>
            </div>
            <div className="col">
              <div className="h-100" style={{ background: '#fff', padding: '1.8rem', borderRadius: '12px', border: '1px solid #e8e2ce', boxShadow: '0 4px 15px rgba(0,0,0,0.04)' }}>
                <h3 style={{ color: '#1b263b', fontFamily: 'serif', fontSize: '1.25rem', marginBottom: '0.8rem' }}>Facilidades de Pago</h3>
                <p style={{ color: '#666', fontSize: '0.92rem', lineHeight: '1.6' }}>Ofrecemos diversas alternativas de financiamiento, tarjetas de crédito y cheques para cubrir diferencias.</p>
              </div>
            </div>
          </div>

          {/* BANNER CONTACTO */}
          <div style={{ background: 'linear-gradient(135deg, #0b1321 0%, #1b263b 100%)', borderRadius: '16px', padding: '2.5rem', textAlign: 'center', color: '#ffffff', boxShadow: '0 8px 25px rgba(0,0,0,0.15)', border: '1px solid #d4af37' }}>
            <h2 style={{ fontSize: '1.8rem', color: '#d4af37', fontFamily: 'serif', marginBottom: '1rem' }}>¿Dudas sobre tus beneficios o cuota mortuoria?</h2>
            <p style={{ maxWidth: '650px', margin: '0 auto 1.8rem', color: '#e0e0e0', fontSize: '1rem', lineHeight: '1.6' }}>Nuestros ejecutivos verificarán de inmediato la cobertura de tu institución o previsión sin compromiso.</p>
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center', flexWrap: 'wrap' }}>
              <Link to="/contacto" className="boton" style={{ padding: '0.85rem 2rem', fontSize: '0.95rem' }}>CONSULTAR CON UN ASESOR</Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}