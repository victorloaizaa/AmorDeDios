// Configuración de Karma para correr las pruebas de Jasmine en Chrome
// npm test               -> corre las pruebas
// npm run test:cobertura -> corre las pruebas y genera el reporte en /coverage
const fs = require('fs');
const path = require('path');
const { createInstrumenter } = require('istanbul-lib-instrument');

// Plugin para esbuild que instrumenta nuestro código (src) para medir la cobertura.
// No se instrumentan los archivos de prueba ni node_modules.
const instrumentador = createInstrumenter({
  esModules: true,
  produceSourceMap: false,
  parserPlugins: ['jsx'],
});

const coberturaPlugin = {
  name: 'cobertura-istanbul',
  setup(build) {
    build.onLoad({ filter: /[\\/]src[\\/].*\.jsx?$/ }, (args) => {
      if (args.path.endsWith('.test.js')) return undefined;
      const codigo = fs.readFileSync(args.path, 'utf8');
      return {
        contents: instrumentador.instrumentSync(codigo, args.path),
        loader: 'jsx',
        resolveDir: path.dirname(args.path),
      };
    });
  },
};

module.exports = function (config) {
  config.set({
    frameworks: ['jasmine'],
    // las pruebas van en archivos *.test.js al lado de cada componente
    files: [{ pattern: 'src/**/*.test.js', watch: false }],
    preprocessors: {
      'src/**/*.test.js': ['esbuild'],
    },
    esbuild: {
      jsx: 'automatic',
      loader: { '.js': 'jsx' },
      plugins: [coberturaPlugin],
    },
    plugins: [
      'karma-jasmine',
      'karma-chrome-launcher',
      'karma-esbuild',
      'karma-spec-reporter',
      'karma-coverage',
    ],
    reporters: ['spec'],
    specReporter: {
      maxLogLines: 5,
      suppressErrorSummary: false,
      suppressFailed: false,
      suppressPassed: false,
      suppressSkipped: true,
      showSpecTiming: true,
    },
    coverageReporter: {
      dir: 'coverage',
      reporters: [
        { type: 'html', subdir: 'html' },
        { type: 'text-summary' },
        { type: 'text' },
        { type: 'json-summary', subdir: '.', file: 'resumen-cobertura.json' },
      ],
    },
    browsers: ['Chrome'],
    // para correr sin abrir la ventana: npx karma start karma.conf.cjs --browsers ChromeSinVentana
    customLaunchers: {
      ChromeSinVentana: { base: 'ChromeHeadless', flags: ['--no-sandbox'] },
    },
    singleRun: true,
  });
};
